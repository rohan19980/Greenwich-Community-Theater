﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using GCT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCT.Tests
{
    [TestClass()]
    public class CreateUserTests
    {
        [TestMethod()]
        public void CreateUserTest()
        {
            Assert.Fail();
        }
    }
}