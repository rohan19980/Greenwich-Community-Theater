﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCT
{
     public class Order
    {

        private int orderID;
        private DateTime date;
        private float cost;
        private int cardNumber;
        private string shippingType;
        private float shippingCost;

        public Order(int orderID, DateTime date, float cost, int cardNumber, string shippingType, float shippingCost)
        {
            this.OrderID = orderID;
            this.Date = date;
            this.Cost = cost;
            this.CardNumber = cardNumber;
            this.ShippingType = shippingType;
            this.ShippingCost = shippingCost;
        }

        public int OrderID { get => orderID; set => orderID = value; }
        public DateTime Date { get => date; set => date = value; }
        public float Cost { get => cost; set => cost = value; }
        public int CardNumber { get => cardNumber; set => cardNumber = value; }
        public string ShippingType { get => shippingType; set => shippingType = value; }
        public float ShippingCost { get => shippingCost; set => shippingCost = value; }
    }
}
