﻿namespace GCT
{
    partial class Shopping_Basket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Shopping_Basket));
            this.CMD_Cancel = new System.Windows.Forms.Button();
            this.CMD_Pay = new System.Windows.Forms.Button();
            this.FLP_Basket = new System.Windows.Forms.FlowLayoutPanel();
            this.LBL_NoChange = new System.Windows.Forms.Label();
            this.LBL_Total = new System.Windows.Forms.Label();
            this.GBX_ShippingMethod = new System.Windows.Forms.GroupBox();
            this.RBT_Second = new System.Windows.Forms.RadioButton();
            this.RBT_First = new System.Windows.Forms.RadioButton();
            this.RBT_Collect = new System.Windows.Forms.RadioButton();
            this.GBX_ShippingMethod.SuspendLayout();
            this.SuspendLayout();
            // 
            // CMD_Cancel
            // 
            this.CMD_Cancel.Location = new System.Drawing.Point(242, 604);
            this.CMD_Cancel.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_Cancel.Name = "CMD_Cancel";
            this.CMD_Cancel.Size = new System.Drawing.Size(125, 35);
            this.CMD_Cancel.TabIndex = 0;
            this.CMD_Cancel.Text = "Cancel";
            this.CMD_Cancel.UseVisualStyleBackColor = true;
            this.CMD_Cancel.Click += new System.EventHandler(this.CMD_Cancel_Click);
            // 
            // CMD_Pay
            // 
            this.CMD_Pay.Location = new System.Drawing.Point(242, 545);
            this.CMD_Pay.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_Pay.Name = "CMD_Pay";
            this.CMD_Pay.Size = new System.Drawing.Size(125, 35);
            this.CMD_Pay.TabIndex = 1;
            this.CMD_Pay.Text = "Pay";
            this.CMD_Pay.UseVisualStyleBackColor = true;
            this.CMD_Pay.Click += new System.EventHandler(this.CMD_Pay_Click);
            // 
            // FLP_Basket
            // 
            this.FLP_Basket.AutoScroll = true;
            this.FLP_Basket.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.FLP_Basket.Location = new System.Drawing.Point(22, 20);
            this.FLP_Basket.Margin = new System.Windows.Forms.Padding(5);
            this.FLP_Basket.Name = "FLP_Basket";
            this.FLP_Basket.Size = new System.Drawing.Size(529, 463);
            this.FLP_Basket.TabIndex = 2;
            this.FLP_Basket.WrapContents = false;
            // 
            // LBL_NoChange
            // 
            this.LBL_NoChange.AutoSize = true;
            this.LBL_NoChange.Location = new System.Drawing.Point(238, 504);
            this.LBL_NoChange.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_NoChange.Name = "LBL_NoChange";
            this.LBL_NoChange.Size = new System.Drawing.Size(59, 20);
            this.LBL_NoChange.TabIndex = 4;
            this.LBL_NoChange.Text = "Total: ";
            // 
            // LBL_Total
            // 
            this.LBL_Total.AutoSize = true;
            this.LBL_Total.Location = new System.Drawing.Point(297, 504);
            this.LBL_Total.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Total.Name = "LBL_Total";
            this.LBL_Total.Size = new System.Drawing.Size(54, 20);
            this.LBL_Total.TabIndex = 5;
            this.LBL_Total.Text = "£1.00";
            // 
            // GBX_ShippingMethod
            // 
            this.GBX_ShippingMethod.Controls.Add(this.RBT_Second);
            this.GBX_ShippingMethod.Controls.Add(this.RBT_First);
            this.GBX_ShippingMethod.Controls.Add(this.RBT_Collect);
            this.GBX_ShippingMethod.Location = new System.Drawing.Point(22, 492);
            this.GBX_ShippingMethod.Margin = new System.Windows.Forms.Padding(5);
            this.GBX_ShippingMethod.Name = "GBX_ShippingMethod";
            this.GBX_ShippingMethod.Padding = new System.Windows.Forms.Padding(5);
            this.GBX_ShippingMethod.Size = new System.Drawing.Size(188, 154);
            this.GBX_ShippingMethod.TabIndex = 6;
            this.GBX_ShippingMethod.TabStop = false;
            this.GBX_ShippingMethod.Text = "Shipping Method";
            // 
            // RBT_Second
            // 
            this.RBT_Second.AutoSize = true;
            this.RBT_Second.Location = new System.Drawing.Point(12, 68);
            this.RBT_Second.Margin = new System.Windows.Forms.Padding(5);
            this.RBT_Second.Name = "RBT_Second";
            this.RBT_Second.Size = new System.Drawing.Size(106, 24);
            this.RBT_Second.TabIndex = 3;
            this.RBT_Second.Text = "2nd Class";
            this.RBT_Second.UseVisualStyleBackColor = true;
            this.RBT_Second.CheckedChanged += new System.EventHandler(this.ShippingTypeChanged);
            // 
            // RBT_First
            // 
            this.RBT_First.AutoSize = true;
            this.RBT_First.Checked = true;
            this.RBT_First.Location = new System.Drawing.Point(12, 31);
            this.RBT_First.Margin = new System.Windows.Forms.Padding(5);
            this.RBT_First.Name = "RBT_First";
            this.RBT_First.Size = new System.Drawing.Size(101, 24);
            this.RBT_First.TabIndex = 2;
            this.RBT_First.TabStop = true;
            this.RBT_First.Text = "1st Class";
            this.RBT_First.UseVisualStyleBackColor = true;
            this.RBT_First.CheckedChanged += new System.EventHandler(this.ShippingTypeChanged);
            // 
            // RBT_Collect
            // 
            this.RBT_Collect.AutoSize = true;
            this.RBT_Collect.Location = new System.Drawing.Point(12, 103);
            this.RBT_Collect.Margin = new System.Windows.Forms.Padding(5);
            this.RBT_Collect.Name = "RBT_Collect";
            this.RBT_Collect.Size = new System.Drawing.Size(82, 24);
            this.RBT_Collect.TabIndex = 1;
            this.RBT_Collect.Text = "Collect";
            this.RBT_Collect.UseVisualStyleBackColor = true;
            this.RBT_Collect.CheckedChanged += new System.EventHandler(this.ShippingTypeChanged);
            // 
            // Shopping_Basket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(580, 715);
            this.Controls.Add(this.GBX_ShippingMethod);
            this.Controls.Add(this.LBL_Total);
            this.Controls.Add(this.LBL_NoChange);
            this.Controls.Add(this.FLP_Basket);
            this.Controls.Add(this.CMD_Pay);
            this.Controls.Add(this.CMD_Cancel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Shopping_Basket";
            this.Text = "Shopping_Basket";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Shopping_Basket_FormClosing);
            this.GBX_ShippingMethod.ResumeLayout(false);
            this.GBX_ShippingMethod.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CMD_Cancel;
        private System.Windows.Forms.Button CMD_Pay;
        private System.Windows.Forms.FlowLayoutPanel FLP_Basket;
        private System.Windows.Forms.Label LBL_NoChange;
        private System.Windows.Forms.Label LBL_Total;
        private System.Windows.Forms.GroupBox GBX_ShippingMethod;
        private System.Windows.Forms.RadioButton RBT_Collect;
        private System.Windows.Forms.RadioButton RBT_Second;
        private System.Windows.Forms.RadioButton RBT_First;
    }
}