﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCT
{
    public class Performance
    {
        private int performacneID;
        private int productionID;
        private DateTime performanceDateTime;

        public Performance(int pfID, int pdID, DateTime pfdt)
        {
            PerformacneID = pfID;
            ProductionID = pdID;
            PerformanceDateTime = pfdt;
        }

        public int PerformacneID { get => performacneID; set => performacneID = value; }
        public int ProductionID { get => productionID; set => productionID = value; }
        public DateTime PerformanceDateTime { get => performanceDateTime; set => performanceDateTime = value; }
    }
}
