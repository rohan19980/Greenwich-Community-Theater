﻿namespace GCT
{
    partial class ChooseSeats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChooseSeats));
            this.LBL_TotalVal = new System.Windows.Forms.Label();
            this.LBL_Total = new System.Windows.Forms.Label();
            this.CMD_Accept = new System.Windows.Forms.Button();
            this.FLP_Cart = new System.Windows.Forms.FlowLayoutPanel();
            this.CMD_AddToCart = new System.Windows.Forms.Button();
            this.TXT_SelectedSeat = new System.Windows.Forms.Label();
            this.CMD_6 = new System.Windows.Forms.Button();
            this.CMD_12 = new System.Windows.Forms.Button();
            this.CMD_18 = new System.Windows.Forms.Button();
            this.CMD_25 = new System.Windows.Forms.Button();
            this.CMD_32 = new System.Windows.Forms.Button();
            this.CMD_5 = new System.Windows.Forms.Button();
            this.CMD_11 = new System.Windows.Forms.Button();
            this.CMD_17 = new System.Windows.Forms.Button();
            this.CMD_24 = new System.Windows.Forms.Button();
            this.CMD_31 = new System.Windows.Forms.Button();
            this.CMD_4 = new System.Windows.Forms.Button();
            this.CMD_10 = new System.Windows.Forms.Button();
            this.CMD_16 = new System.Windows.Forms.Button();
            this.CMD_23 = new System.Windows.Forms.Button();
            this.CMD_30 = new System.Windows.Forms.Button();
            this.CMD_22 = new System.Windows.Forms.Button();
            this.CMD_29 = new System.Windows.Forms.Button();
            this.CMD_3 = new System.Windows.Forms.Button();
            this.CMD_9 = new System.Windows.Forms.Button();
            this.CMD_15 = new System.Windows.Forms.Button();
            this.CMD_21 = new System.Windows.Forms.Button();
            this.CMD_28 = new System.Windows.Forms.Button();
            this.CMD_2 = new System.Windows.Forms.Button();
            this.CMD_8 = new System.Windows.Forms.Button();
            this.CMD_14 = new System.Windows.Forms.Button();
            this.CMD_20 = new System.Windows.Forms.Button();
            this.CMD_27 = new System.Windows.Forms.Button();
            this.CMD_1 = new System.Windows.Forms.Button();
            this.CMD_7 = new System.Windows.Forms.Button();
            this.CMD_13 = new System.Windows.Forms.Button();
            this.CMD_19 = new System.Windows.Forms.Button();
            this.CMD_26 = new System.Windows.Forms.Button();
            this.CMD_Cancel = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.GRP_Age = new System.Windows.Forms.GroupBox();
            this.RBT_Under12 = new System.Windows.Forms.RadioButton();
            this.RBT_Adult = new System.Windows.Forms.RadioButton();
            this.RBT_OAP = new System.Windows.Forms.RadioButton();
            this.GRP_Age.SuspendLayout();
            this.SuspendLayout();
            // 
            // LBL_TotalVal
            // 
            this.LBL_TotalVal.AutoSize = true;
            this.LBL_TotalVal.Location = new System.Drawing.Point(865, 385);
            this.LBL_TotalVal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_TotalVal.Name = "LBL_TotalVal";
            this.LBL_TotalVal.Size = new System.Drawing.Size(17, 18);
            this.LBL_TotalVal.TabIndex = 87;
            this.LBL_TotalVal.Text = "0";
            // 
            // LBL_Total
            // 
            this.LBL_Total.AutoSize = true;
            this.LBL_Total.Location = new System.Drawing.Point(798, 385);
            this.LBL_Total.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Total.Name = "LBL_Total";
            this.LBL_Total.Size = new System.Drawing.Size(51, 18);
            this.LBL_Total.TabIndex = 86;
            this.LBL_Total.Text = "Total:";
            // 
            // CMD_Accept
            // 
            this.CMD_Accept.Location = new System.Drawing.Point(560, 469);
            this.CMD_Accept.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_Accept.Name = "CMD_Accept";
            this.CMD_Accept.Size = new System.Drawing.Size(125, 32);
            this.CMD_Accept.TabIndex = 85;
            this.CMD_Accept.Text = "Accept";
            this.CMD_Accept.UseVisualStyleBackColor = true;
            this.CMD_Accept.Click += new System.EventHandler(this.CMD_Accept_Click);
            // 
            // FLP_Cart
            // 
            this.FLP_Cart.AutoScroll = true;
            this.FLP_Cart.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.FLP_Cart.Location = new System.Drawing.Point(560, 78);
            this.FLP_Cart.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.FLP_Cart.Name = "FLP_Cart";
            this.FLP_Cart.Size = new System.Drawing.Size(392, 294);
            this.FLP_Cart.TabIndex = 84;
            this.FLP_Cart.WrapContents = false;
            // 
            // CMD_AddToCart
            // 
            this.CMD_AddToCart.Location = new System.Drawing.Point(43, 469);
            this.CMD_AddToCart.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_AddToCart.Name = "CMD_AddToCart";
            this.CMD_AddToCart.Size = new System.Drawing.Size(125, 32);
            this.CMD_AddToCart.TabIndex = 83;
            this.CMD_AddToCart.Text = "Add ";
            this.CMD_AddToCart.UseVisualStyleBackColor = true;
            this.CMD_AddToCart.Click += new System.EventHandler(this.CMD_AddToCart_Click);
            // 
            // TXT_SelectedSeat
            // 
            this.TXT_SelectedSeat.AutoSize = true;
            this.TXT_SelectedSeat.Location = new System.Drawing.Point(40, 385);
            this.TXT_SelectedSeat.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.TXT_SelectedSeat.Name = "TXT_SelectedSeat";
            this.TXT_SelectedSeat.Size = new System.Drawing.Size(122, 18);
            this.TXT_SelectedSeat.TabIndex = 82;
            this.TXT_SelectedSeat.Text = "Selected Seat: ";
            // 
            // CMD_6
            // 
            this.CMD_6.Location = new System.Drawing.Point(470, 317);
            this.CMD_6.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_6.Name = "CMD_6";
            this.CMD_6.Size = new System.Drawing.Size(62, 32);
            this.CMD_6.TabIndex = 81;
            this.CMD_6.Text = "6";
            this.CMD_6.UseVisualStyleBackColor = true;
            this.CMD_6.Click += new System.EventHandler(this.CMD_6_Click);
            // 
            // CMD_12
            // 
            this.CMD_12.Location = new System.Drawing.Point(470, 276);
            this.CMD_12.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_12.Name = "CMD_12";
            this.CMD_12.Size = new System.Drawing.Size(62, 32);
            this.CMD_12.TabIndex = 80;
            this.CMD_12.Text = "12";
            this.CMD_12.UseVisualStyleBackColor = true;
            this.CMD_12.Click += new System.EventHandler(this.CMD_12_Click);
            // 
            // CMD_18
            // 
            this.CMD_18.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CMD_18.Location = new System.Drawing.Point(470, 201);
            this.CMD_18.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_18.Name = "CMD_18";
            this.CMD_18.Size = new System.Drawing.Size(62, 32);
            this.CMD_18.TabIndex = 79;
            this.CMD_18.Text = "18";
            this.CMD_18.UseVisualStyleBackColor = false;
            this.CMD_18.Click += new System.EventHandler(this.CMD_18_Click);
            // 
            // CMD_25
            // 
            this.CMD_25.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_25.Location = new System.Drawing.Point(470, 119);
            this.CMD_25.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_25.Name = "CMD_25";
            this.CMD_25.Size = new System.Drawing.Size(62, 32);
            this.CMD_25.TabIndex = 78;
            this.CMD_25.Text = "25";
            this.CMD_25.UseVisualStyleBackColor = false;
            this.CMD_25.Click += new System.EventHandler(this.CMD_25_Click);
            // 
            // CMD_32
            // 
            this.CMD_32.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_32.Location = new System.Drawing.Point(470, 78);
            this.CMD_32.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_32.Name = "CMD_32";
            this.CMD_32.Size = new System.Drawing.Size(62, 32);
            this.CMD_32.TabIndex = 77;
            this.CMD_32.Text = "32";
            this.CMD_32.UseVisualStyleBackColor = false;
            this.CMD_32.Click += new System.EventHandler(this.CMD_32_Click);
            // 
            // CMD_5
            // 
            this.CMD_5.Location = new System.Drawing.Point(398, 317);
            this.CMD_5.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_5.Name = "CMD_5";
            this.CMD_5.Size = new System.Drawing.Size(62, 32);
            this.CMD_5.TabIndex = 76;
            this.CMD_5.Text = "5";
            this.CMD_5.UseVisualStyleBackColor = true;
            this.CMD_5.Click += new System.EventHandler(this.CMD_5_Click);
            // 
            // CMD_11
            // 
            this.CMD_11.Location = new System.Drawing.Point(398, 276);
            this.CMD_11.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_11.Name = "CMD_11";
            this.CMD_11.Size = new System.Drawing.Size(62, 32);
            this.CMD_11.TabIndex = 75;
            this.CMD_11.Text = "11";
            this.CMD_11.UseVisualStyleBackColor = true;
            this.CMD_11.Click += new System.EventHandler(this.CMD_11_Click);
            // 
            // CMD_17
            // 
            this.CMD_17.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CMD_17.Location = new System.Drawing.Point(398, 201);
            this.CMD_17.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_17.Name = "CMD_17";
            this.CMD_17.Size = new System.Drawing.Size(62, 32);
            this.CMD_17.TabIndex = 74;
            this.CMD_17.Text = "17";
            this.CMD_17.UseVisualStyleBackColor = false;
            this.CMD_17.Click += new System.EventHandler(this.CMD_17_Click);
            // 
            // CMD_24
            // 
            this.CMD_24.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_24.Location = new System.Drawing.Point(398, 119);
            this.CMD_24.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_24.Name = "CMD_24";
            this.CMD_24.Size = new System.Drawing.Size(62, 32);
            this.CMD_24.TabIndex = 73;
            this.CMD_24.Text = "24";
            this.CMD_24.UseVisualStyleBackColor = false;
            this.CMD_24.Click += new System.EventHandler(this.CMD_24_Click);
            // 
            // CMD_31
            // 
            this.CMD_31.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_31.Location = new System.Drawing.Point(398, 78);
            this.CMD_31.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_31.Name = "CMD_31";
            this.CMD_31.Size = new System.Drawing.Size(62, 32);
            this.CMD_31.TabIndex = 72;
            this.CMD_31.Text = "31";
            this.CMD_31.UseVisualStyleBackColor = false;
            this.CMD_31.Click += new System.EventHandler(this.CMD_31_Click);
            // 
            // CMD_4
            // 
            this.CMD_4.Location = new System.Drawing.Point(327, 317);
            this.CMD_4.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_4.Name = "CMD_4";
            this.CMD_4.Size = new System.Drawing.Size(62, 32);
            this.CMD_4.TabIndex = 71;
            this.CMD_4.Text = "4";
            this.CMD_4.UseVisualStyleBackColor = true;
            this.CMD_4.Click += new System.EventHandler(this.CMD_4_Click);
            // 
            // CMD_10
            // 
            this.CMD_10.Location = new System.Drawing.Point(327, 276);
            this.CMD_10.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_10.Name = "CMD_10";
            this.CMD_10.Size = new System.Drawing.Size(62, 32);
            this.CMD_10.TabIndex = 70;
            this.CMD_10.Text = "10";
            this.CMD_10.UseVisualStyleBackColor = true;
            this.CMD_10.Click += new System.EventHandler(this.CMD_10_Click);
            // 
            // CMD_16
            // 
            this.CMD_16.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CMD_16.Location = new System.Drawing.Point(327, 201);
            this.CMD_16.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_16.Name = "CMD_16";
            this.CMD_16.Size = new System.Drawing.Size(62, 32);
            this.CMD_16.TabIndex = 69;
            this.CMD_16.Text = "16";
            this.CMD_16.UseVisualStyleBackColor = false;
            this.CMD_16.Click += new System.EventHandler(this.CMD_16_Click);
            // 
            // CMD_23
            // 
            this.CMD_23.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CMD_23.Location = new System.Drawing.Point(327, 119);
            this.CMD_23.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_23.Name = "CMD_23";
            this.CMD_23.Size = new System.Drawing.Size(62, 32);
            this.CMD_23.TabIndex = 68;
            this.CMD_23.Text = "23";
            this.CMD_23.UseVisualStyleBackColor = false;
            this.CMD_23.Click += new System.EventHandler(this.CMD_23_Click);
            // 
            // CMD_30
            // 
            this.CMD_30.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_30.Location = new System.Drawing.Point(327, 78);
            this.CMD_30.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_30.Name = "CMD_30";
            this.CMD_30.Size = new System.Drawing.Size(62, 32);
            this.CMD_30.TabIndex = 67;
            this.CMD_30.Text = "30";
            this.CMD_30.UseVisualStyleBackColor = false;
            this.CMD_30.Click += new System.EventHandler(this.CMD_30_Click);
            // 
            // CMD_22
            // 
            this.CMD_22.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CMD_22.Location = new System.Drawing.Point(255, 119);
            this.CMD_22.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_22.Name = "CMD_22";
            this.CMD_22.Size = new System.Drawing.Size(62, 32);
            this.CMD_22.TabIndex = 66;
            this.CMD_22.Text = "22";
            this.CMD_22.UseVisualStyleBackColor = false;
            this.CMD_22.Click += new System.EventHandler(this.CMD_22_Click);
            // 
            // CMD_29
            // 
            this.CMD_29.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_29.Location = new System.Drawing.Point(255, 78);
            this.CMD_29.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_29.Name = "CMD_29";
            this.CMD_29.Size = new System.Drawing.Size(62, 32);
            this.CMD_29.TabIndex = 65;
            this.CMD_29.Text = "29";
            this.CMD_29.UseVisualStyleBackColor = false;
            this.CMD_29.Click += new System.EventHandler(this.CMD_29_Click);
            // 
            // CMD_3
            // 
            this.CMD_3.Location = new System.Drawing.Point(183, 317);
            this.CMD_3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_3.Name = "CMD_3";
            this.CMD_3.Size = new System.Drawing.Size(62, 32);
            this.CMD_3.TabIndex = 64;
            this.CMD_3.Text = "3";
            this.CMD_3.UseVisualStyleBackColor = true;
            this.CMD_3.Click += new System.EventHandler(this.CMD_3_Click);
            // 
            // CMD_9
            // 
            this.CMD_9.Location = new System.Drawing.Point(183, 276);
            this.CMD_9.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_9.Name = "CMD_9";
            this.CMD_9.Size = new System.Drawing.Size(62, 32);
            this.CMD_9.TabIndex = 63;
            this.CMD_9.Text = "9";
            this.CMD_9.UseVisualStyleBackColor = true;
            this.CMD_9.Click += new System.EventHandler(this.CMD_9_Click);
            // 
            // CMD_15
            // 
            this.CMD_15.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CMD_15.Location = new System.Drawing.Point(183, 201);
            this.CMD_15.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_15.Name = "CMD_15";
            this.CMD_15.Size = new System.Drawing.Size(62, 32);
            this.CMD_15.TabIndex = 62;
            this.CMD_15.Text = "15";
            this.CMD_15.UseVisualStyleBackColor = false;
            this.CMD_15.Click += new System.EventHandler(this.CMD_15_Click);
            // 
            // CMD_21
            // 
            this.CMD_21.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CMD_21.Location = new System.Drawing.Point(183, 119);
            this.CMD_21.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_21.Name = "CMD_21";
            this.CMD_21.Size = new System.Drawing.Size(62, 32);
            this.CMD_21.TabIndex = 61;
            this.CMD_21.Text = "21";
            this.CMD_21.UseVisualStyleBackColor = false;
            this.CMD_21.Click += new System.EventHandler(this.CMD_21_Click);
            // 
            // CMD_28
            // 
            this.CMD_28.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_28.Location = new System.Drawing.Point(183, 78);
            this.CMD_28.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_28.Name = "CMD_28";
            this.CMD_28.Size = new System.Drawing.Size(62, 32);
            this.CMD_28.TabIndex = 60;
            this.CMD_28.Text = "28";
            this.CMD_28.UseVisualStyleBackColor = false;
            this.CMD_28.Click += new System.EventHandler(this.CMD_28_Click);
            // 
            // CMD_2
            // 
            this.CMD_2.Location = new System.Drawing.Point(112, 317);
            this.CMD_2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_2.Name = "CMD_2";
            this.CMD_2.Size = new System.Drawing.Size(62, 32);
            this.CMD_2.TabIndex = 59;
            this.CMD_2.Text = "2";
            this.CMD_2.UseVisualStyleBackColor = true;
            this.CMD_2.Click += new System.EventHandler(this.CMD_2_Click);
            // 
            // CMD_8
            // 
            this.CMD_8.Location = new System.Drawing.Point(112, 276);
            this.CMD_8.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_8.Name = "CMD_8";
            this.CMD_8.Size = new System.Drawing.Size(62, 32);
            this.CMD_8.TabIndex = 58;
            this.CMD_8.Text = "8";
            this.CMD_8.UseVisualStyleBackColor = true;
            this.CMD_8.Click += new System.EventHandler(this.CMD_8_Click);
            // 
            // CMD_14
            // 
            this.CMD_14.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CMD_14.Location = new System.Drawing.Point(112, 201);
            this.CMD_14.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_14.Name = "CMD_14";
            this.CMD_14.Size = new System.Drawing.Size(62, 32);
            this.CMD_14.TabIndex = 57;
            this.CMD_14.Text = "14";
            this.CMD_14.UseVisualStyleBackColor = false;
            this.CMD_14.Click += new System.EventHandler(this.CMD_14_Click);
            // 
            // CMD_20
            // 
            this.CMD_20.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_20.Location = new System.Drawing.Point(112, 119);
            this.CMD_20.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_20.Name = "CMD_20";
            this.CMD_20.Size = new System.Drawing.Size(62, 32);
            this.CMD_20.TabIndex = 56;
            this.CMD_20.Text = "20";
            this.CMD_20.UseVisualStyleBackColor = false;
            this.CMD_20.Click += new System.EventHandler(this.CMD_20_Click);
            // 
            // CMD_27
            // 
            this.CMD_27.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_27.Location = new System.Drawing.Point(112, 78);
            this.CMD_27.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_27.Name = "CMD_27";
            this.CMD_27.Size = new System.Drawing.Size(62, 32);
            this.CMD_27.TabIndex = 55;
            this.CMD_27.Text = "27";
            this.CMD_27.UseVisualStyleBackColor = false;
            this.CMD_27.Click += new System.EventHandler(this.CMD_27_Click);
            // 
            // CMD_1
            // 
            this.CMD_1.Location = new System.Drawing.Point(40, 317);
            this.CMD_1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_1.Name = "CMD_1";
            this.CMD_1.Size = new System.Drawing.Size(62, 32);
            this.CMD_1.TabIndex = 54;
            this.CMD_1.Text = "1";
            this.CMD_1.UseVisualStyleBackColor = true;
            this.CMD_1.Click += new System.EventHandler(this.CMD_1_Click);
            // 
            // CMD_7
            // 
            this.CMD_7.Location = new System.Drawing.Point(40, 276);
            this.CMD_7.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_7.Name = "CMD_7";
            this.CMD_7.Size = new System.Drawing.Size(62, 32);
            this.CMD_7.TabIndex = 53;
            this.CMD_7.Text = "7";
            this.CMD_7.UseVisualStyleBackColor = true;
            this.CMD_7.Click += new System.EventHandler(this.CMD_7_Click);
            // 
            // CMD_13
            // 
            this.CMD_13.BackColor = System.Drawing.SystemColors.ControlDark;
            this.CMD_13.Location = new System.Drawing.Point(40, 201);
            this.CMD_13.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_13.Name = "CMD_13";
            this.CMD_13.Size = new System.Drawing.Size(62, 32);
            this.CMD_13.TabIndex = 52;
            this.CMD_13.Text = "13";
            this.CMD_13.UseVisualStyleBackColor = false;
            this.CMD_13.Click += new System.EventHandler(this.CMD_13_Click);
            // 
            // CMD_19
            // 
            this.CMD_19.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_19.Location = new System.Drawing.Point(40, 119);
            this.CMD_19.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_19.Name = "CMD_19";
            this.CMD_19.Size = new System.Drawing.Size(62, 32);
            this.CMD_19.TabIndex = 51;
            this.CMD_19.Text = "19";
            this.CMD_19.UseVisualStyleBackColor = false;
            this.CMD_19.Click += new System.EventHandler(this.CMD_19_Click);
            // 
            // CMD_26
            // 
            this.CMD_26.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.CMD_26.Location = new System.Drawing.Point(40, 78);
            this.CMD_26.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_26.Name = "CMD_26";
            this.CMD_26.Size = new System.Drawing.Size(62, 32);
            this.CMD_26.TabIndex = 50;
            this.CMD_26.Text = "26";
            this.CMD_26.UseVisualStyleBackColor = false;
            this.CMD_26.Click += new System.EventHandler(this.CMD_26_Click);
            // 
            // CMD_Cancel
            // 
            this.CMD_Cancel.Location = new System.Drawing.Point(803, 469);
            this.CMD_Cancel.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CMD_Cancel.Name = "CMD_Cancel";
            this.CMD_Cancel.Size = new System.Drawing.Size(125, 32);
            this.CMD_Cancel.TabIndex = 88;
            this.CMD_Cancel.Text = "Cancel";
            this.CMD_Cancel.UseVisualStyleBackColor = true;
            this.CMD_Cancel.Click += new System.EventHandler(this.CMD_Cancel_Click);
            // 
            // GRP_Age
            // 
            this.GRP_Age.Controls.Add(this.RBT_OAP);
            this.GRP_Age.Controls.Add(this.RBT_Adult);
            this.GRP_Age.Controls.Add(this.RBT_Under12);
            this.GRP_Age.Location = new System.Drawing.Point(332, 356);
            this.GRP_Age.Name = "GRP_Age";
            this.GRP_Age.Size = new System.Drawing.Size(200, 100);
            this.GRP_Age.TabIndex = 89;
            this.GRP_Age.TabStop = false;
            this.GRP_Age.Text = "Choose Age Range";
            // 
            // RBT_Under12
            // 
            this.RBT_Under12.AutoSize = true;
            this.RBT_Under12.Location = new System.Drawing.Point(6, 23);
            this.RBT_Under12.Name = "RBT_Under12";
            this.RBT_Under12.Size = new System.Drawing.Size(89, 22);
            this.RBT_Under12.TabIndex = 0;
            this.RBT_Under12.TabStop = true;
            this.RBT_Under12.Text = "Under12";
            this.RBT_Under12.UseVisualStyleBackColor = true;
            // 
            // RBT_Adult
            // 
            this.RBT_Adult.AutoSize = true;
            this.RBT_Adult.Location = new System.Drawing.Point(6, 51);
            this.RBT_Adult.Name = "RBT_Adult";
            this.RBT_Adult.Size = new System.Drawing.Size(63, 22);
            this.RBT_Adult.TabIndex = 1;
            this.RBT_Adult.TabStop = true;
            this.RBT_Adult.Text = "Adult";
            this.RBT_Adult.UseVisualStyleBackColor = true;
            // 
            // RBT_OAP
            // 
            this.RBT_OAP.AutoSize = true;
            this.RBT_OAP.Location = new System.Drawing.Point(6, 79);
            this.RBT_OAP.Name = "RBT_OAP";
            this.RBT_OAP.Size = new System.Drawing.Size(85, 22);
            this.RBT_OAP.TabIndex = 2;
            this.RBT_OAP.TabStop = true;
            this.RBT_OAP.Text = "Over 65";
            this.RBT_OAP.UseVisualStyleBackColor = true;
            // 
            // ChooseSeats
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(960, 518);
            this.Controls.Add(this.GRP_Age);
            this.Controls.Add(this.CMD_Cancel);
            this.Controls.Add(this.LBL_TotalVal);
            this.Controls.Add(this.LBL_Total);
            this.Controls.Add(this.CMD_Accept);
            this.Controls.Add(this.FLP_Cart);
            this.Controls.Add(this.CMD_AddToCart);
            this.Controls.Add(this.TXT_SelectedSeat);
            this.Controls.Add(this.CMD_6);
            this.Controls.Add(this.CMD_12);
            this.Controls.Add(this.CMD_18);
            this.Controls.Add(this.CMD_25);
            this.Controls.Add(this.CMD_32);
            this.Controls.Add(this.CMD_5);
            this.Controls.Add(this.CMD_11);
            this.Controls.Add(this.CMD_17);
            this.Controls.Add(this.CMD_24);
            this.Controls.Add(this.CMD_31);
            this.Controls.Add(this.CMD_4);
            this.Controls.Add(this.CMD_10);
            this.Controls.Add(this.CMD_16);
            this.Controls.Add(this.CMD_23);
            this.Controls.Add(this.CMD_30);
            this.Controls.Add(this.CMD_22);
            this.Controls.Add(this.CMD_29);
            this.Controls.Add(this.CMD_3);
            this.Controls.Add(this.CMD_9);
            this.Controls.Add(this.CMD_15);
            this.Controls.Add(this.CMD_21);
            this.Controls.Add(this.CMD_28);
            this.Controls.Add(this.CMD_2);
            this.Controls.Add(this.CMD_8);
            this.Controls.Add(this.CMD_14);
            this.Controls.Add(this.CMD_20);
            this.Controls.Add(this.CMD_27);
            this.Controls.Add(this.CMD_1);
            this.Controls.Add(this.CMD_7);
            this.Controls.Add(this.CMD_13);
            this.Controls.Add(this.CMD_19);
            this.Controls.Add(this.CMD_26);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "ChooseSeats";
            this.Text = "ChooseSeats";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ChooseSeats_FormClosing);
            this.Load += new System.EventHandler(this.ChooseSeats_Load);
            this.VisibleChanged += new System.EventHandler(this.ChooseSeats_VisibleChanged);
            this.GRP_Age.ResumeLayout(false);
            this.GRP_Age.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBL_TotalVal;
        private System.Windows.Forms.Label LBL_Total;
        private System.Windows.Forms.Button CMD_Accept;
        private System.Windows.Forms.FlowLayoutPanel FLP_Cart;
        private System.Windows.Forms.Button CMD_AddToCart;
        private System.Windows.Forms.Label TXT_SelectedSeat;
        private System.Windows.Forms.Button CMD_6;
        private System.Windows.Forms.Button CMD_12;
        private System.Windows.Forms.Button CMD_18;
        private System.Windows.Forms.Button CMD_25;
        private System.Windows.Forms.Button CMD_32;
        private System.Windows.Forms.Button CMD_5;
        private System.Windows.Forms.Button CMD_11;
        private System.Windows.Forms.Button CMD_17;
        private System.Windows.Forms.Button CMD_24;
        private System.Windows.Forms.Button CMD_31;
        private System.Windows.Forms.Button CMD_4;
        private System.Windows.Forms.Button CMD_10;
        private System.Windows.Forms.Button CMD_16;
        private System.Windows.Forms.Button CMD_23;
        private System.Windows.Forms.Button CMD_30;
        private System.Windows.Forms.Button CMD_22;
        private System.Windows.Forms.Button CMD_29;
        private System.Windows.Forms.Button CMD_3;
        private System.Windows.Forms.Button CMD_9;
        private System.Windows.Forms.Button CMD_15;
        private System.Windows.Forms.Button CMD_21;
        private System.Windows.Forms.Button CMD_28;
        private System.Windows.Forms.Button CMD_2;
        private System.Windows.Forms.Button CMD_8;
        private System.Windows.Forms.Button CMD_14;
        private System.Windows.Forms.Button CMD_20;
        private System.Windows.Forms.Button CMD_27;
        private System.Windows.Forms.Button CMD_1;
        private System.Windows.Forms.Button CMD_7;
        private System.Windows.Forms.Button CMD_13;
        private System.Windows.Forms.Button CMD_19;
        private System.Windows.Forms.Button CMD_26;
        private System.Windows.Forms.Button CMD_Cancel;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.GroupBox GRP_Age;
        private System.Windows.Forms.RadioButton RBT_OAP;
        private System.Windows.Forms.RadioButton RBT_Adult;
        private System.Windows.Forms.RadioButton RBT_Under12;
    }
}