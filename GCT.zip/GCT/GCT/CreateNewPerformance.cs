﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public partial class CreateNewPerformance : Form
    {
        private int productionID;
        private Model model;

        public CreateNewPerformance(int ID, Model model)
        {
            InitializeComponent();
            productionID = ID;
            this.model = model;
        }

        private void CMD_Confirm_Click(object sender, EventArgs e)
        {

            DateTime pfTime = DateTime.Parse(DateTime.Parse(DTP_Date.Text).ToShortDateString() + " " + DateTime.Parse(DTP_Time.Text).ToShortTimeString());

            TXT_BandA.Text = string.Format("{0:0.00}", double.Parse(TXT_BandA.Text)); 
            TXT_BandB.Text = string.Format("{0:0.00}", double.Parse(TXT_BandB.Text)); 
            TXT_BandC.Text = string.Format("{0:0.00}", double.Parse(TXT_BandC.Text)); 


            if (pfTime > DateTime.Now)
            {
                model.CreatePerformance(productionID, pfTime, float.Parse(TXT_BandA.Text), float.Parse(TXT_BandB.Text), float.Parse(TXT_BandC.Text));

                ChooseShow cs = (ChooseShow)this.Owner;
                cs.UpdatePerformanceCBX(pfTime);
                cs.Show();
                Close();
            }
            else
            {
                MessageBox.Show("The DateTime provided is in the past.");
            }
        }

        private void CreateNewPerformance_FormClosing(object sender, FormClosingEventArgs e)
        {
            ReturnView.ViewLastForm(Owner);
        }
    }


}
