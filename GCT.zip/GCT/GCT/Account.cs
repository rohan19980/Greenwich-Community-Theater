﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCT
{
    public class Account
    {
        private int accountID;
        private string accountFirstName;
        private string accountLastName;
        private string accountEmail;
        private string accountUsername;
        private string accountPassword;
        private string accountAddress;
        private string accountPhone;
        private int accountAccess;

        //get Account
        public Account(int ID, string firstName, string lastName, string email, string username, string password, string address, string phone, int access)
        {
            accountID = ID;
            AccountFirstName = firstName;
            AccountLastName = lastName;
            accountEmail = email;
            accountUsername = username;
            accountPassword = password;
            accountAddress = address;
            accountPhone = phone;
            accountAccess = access;
            
        }

        public int AccountID { get => accountID; set => accountID = value; }
        
        public string AccountEmail { get => accountEmail; set => accountEmail = value; }
        public string AccountFirstName { get => accountFirstName; set => accountFirstName = value; }
        public string AccountLastName { get => accountLastName; set => accountLastName = value; }
        public string AccountUsername { get => accountUsername; set => accountUsername = value; }
        public string AccountPassword { get => accountPassword; set => accountPassword = value; }
        public string AccountAddress { get => accountAddress; set => accountAddress = value; }
        public string AccountPhone { get => accountPhone; set => accountPhone = value; }
        public int AccountAccess { get => accountAccess; set => accountAccess = value; }
    }
}
