﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public partial class CheckOut : Form
    {
        public CheckOut(Model model, string cost, string shippingType, double shippingCost)
        {
            InitializeComponent();
            this.model = model;
            LBL_Due.Text = cost;
            this.shippingType = shippingType;
            this.shippingCost = shippingCost;
        }

        private Model model;
        private string shippingType;
        private double shippingCost;
        private bool checkoutSuccessful = false;

        private void CMD_Confirm_Click(object sender, EventArgs e)
        {
            if (TXT_CardNumber.Text.Length == 16 && (TXT_CardNumber.Text.All(Char.IsDigit)) && TXT_CSC.Text.Length == 3 && TXT_CSC.Text.All(Char.IsDigit))
            {
                //visa check
                double.Parse(TXT_CardNumber.Text);
                if (VisaCheck.CheckCard(double.Parse(TXT_CardNumber.Text), int.Parse(DTP_ExpiryDate.Value.ToString("MM")), int.Parse(DTP_ExpiryDate.Value.ToString("yy")), int.Parse(TXT_CSC.Text)) == true)
                {
                    model.CreateOrder(DateTime.Now, double.Parse(LBL_Due.Text, NumberStyles.Currency), double.Parse(TXT_CardNumber.Text), model.CurrentUser.AccountID, shippingType, shippingCost);
                    checkoutSuccessful = true;
                }
                else
                {
                    MessageBox.Show("Error varifying card details");
                }
            }
            else
            {
                MessageBox.Show("Input Error");
            }

            Close();
        }

        private void CheckOut_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (checkoutSuccessful)
            {
               while (model.Cart.Count > 0) { 
                    model.Ticket = model.Cart[0];
                    model.Cart.RemoveAt(0);
                }

                ChooseShow cs = new ChooseShow(model);
                Owner = cs;
                cs.Show();
            }
            else
            {
                ReturnView.ViewLastForm(Owner);
            }
        }
    }
}
