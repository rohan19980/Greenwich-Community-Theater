﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public partial class ShowReviews : Form
    {
        public ShowReviews(Model model)
        {
            InitializeComponent();
            this.model = model;
            model.GetReviews(model.SelectedProductionID);


            for (int i = 0; i < model.Reviews.Count(); i++)
            {
                AddNewRTB(i);
            }
        }


        private void ShowReviews_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                Controls.Add(CreateMenuStrip.GetMenuStrip(model, this));
                foreach (Control c in Controls)
                {
                    if (c.GetType() == typeof(MenuStrip))
                    {
                        Controls.Remove(c);
                    }
                }
                
            }
        }

        private Model model;

        private void AddNewRTB(int i)
        {
            RichTextBox RTB = new RichTextBox();
            RTB.Width = FLP_Reviews.Width - 10;
            RTB.Text = model.Reviews[i].ReviewData;
            RTB.Enabled = false;
            RTB.SelectAll();
            RTB.SelectionColor = Color.Black;
            FLP_Reviews.Controls.Add(RTB);
        }

        private void CMD_AddReview_Click(object sender, EventArgs e)
        {
            model.CreateReview( RTB_NewReview.Text, model.SelectedProductionID, model.CurrentUser.AccountID);
            AddNewRTB(model.Reviews.Count() - 1);
            RTB_NewReview.Text = "";
        }

        private void CMD_Close_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ShowReviews_FormClosing(object sender, FormClosingEventArgs e)
        {
            ReturnView.ViewLastForm(Owner);
        }
    }
}
