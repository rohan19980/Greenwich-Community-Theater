﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public partial class CreateUser : Form
    {
        public CreateUser(Model model, Form currentForm, bool guestAccount)
        {
            InitializeComponent();
            this.model = model;
            this.Owner = currentForm;
            this.guestAccount = guestAccount;

            if (guestAccount == true)
            {
                LBL_Username.Hide();
                TXT_UserName.Hide();
                LBL_Password.Hide();
                TXT_Password.Hide();
                LBL_Type.Hide();
                CBX_AccountType.Hide();
            }
        }

        private Model model;
        private bool guestAccount;

        private void CMD_Submit_Click(object sender, EventArgs e)
        {

            int accessLevel = 0;
            bool validLevel = true;

            if (guestAccount == true)
            {
                model.CreateAccount(TXT_FirstName.Text, TXT_LastName.Text, TXT_Email.Text, TXT_Address.Text, TXT_PhoneNumber.Text);
            }
            else
            {

                switch (CBX_AccountType.Text)
                {
                    case "Customer":
                        accessLevel = 1;
                        break;
                    case "Agency":
                        accessLevel = 2;
                        break;
                    case "Staff":
                        accessLevel = 3;
                        if (model.CurrentUser.AccountAccess < 2)
                        {
                            validLevel = false;
                        }
                        break;
                    case "Admin":
                        accessLevel = 4;
                        if (model.CurrentUser.AccountAccess < 3)
                        {
                            validLevel = false;
                        }
                        break;
                }
            }
            if (validLevel == true)
            {
                bool valid = true;

                foreach (TextBox tb in Controls.OfType<TextBox>())
                {
                    if (tb.Text == "")
                    {
                        valid = false;
                    }

                    if (tb.Name == "TXT_Email")
                    {
                        try
                        {
                            MailAddress email = new MailAddress(TXT_Email.Text);
                        }
                        catch
                        {
                            valid = false;
                        }
                    }

                    if (tb.Name == "TXT_PhoneNumber")
                    {
                        tb.Text.Replace(" ", "");
                        if ((!tb.Text.All(Char.IsDigit) || tb.Text.Length != 11))
                        {
                            valid = false;
                        }
                    }
                }

                if (valid)
                {
                    model.CreateAccount(TXT_FirstName.Text, TXT_LastName.Text, TXT_Email.Text, TXT_UserName.Text, TXT_Password.Text, TXT_Address.Text, TXT_PhoneNumber.Text, accessLevel);
                    Close();
                }
                else
                {
                    MessageBox.Show("1 or more fields have been entered incorrectly.");
                }
            }
            else
            {
                MessageBox.Show("Account access level is not high enough to create this account type.");
            }
        }

        private void CreateUser_FormClosing(object sender, FormClosingEventArgs e)
        {
            ReturnView.ViewLastForm(Owner);
        }
    }
}
