﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCT
{
    public class Production
    {
        private int productionID;
        private string productionName;
        private string description;
        private DateTime startDate;
        private DateTime endDate;

        public Production(int pdID, string pdName, string desc, DateTime sd, DateTime ed)
        {
            ProductionID = pdID;
            ProductionName = pdName;
            Description = desc;
            StartDate = sd;
            EndDate = ed;
        }

        public int ProductionID { get => productionID; set => productionID = value; }
        public string ProductionName { get => productionName; set => productionName = value; }
        public string Description { get => description; set => description = value; }
        public DateTime StartDate { get => startDate; set => startDate = value; }
        public DateTime EndDate { get => endDate; set => endDate = value; }
    }
}
