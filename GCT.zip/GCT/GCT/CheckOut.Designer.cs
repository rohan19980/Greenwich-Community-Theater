﻿namespace GCT
{
    partial class CheckOut
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CheckOut));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CMD_Confirm = new System.Windows.Forms.Button();
            this.CMD_Cancel = new System.Windows.Forms.Button();
            this.LBL_Due = new System.Windows.Forms.Label();
            this.TXT_CardNumber = new System.Windows.Forms.TextBox();
            this.TXT_CSC = new System.Windows.Forms.TextBox();
            this.DTP_ExpiryDate = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Amount Due:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 63);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Card Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 108);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Expiry Date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 154);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "CSC:";
            // 
            // CMD_Confirm
            // 
            this.CMD_Confirm.Location = new System.Drawing.Point(20, 218);
            this.CMD_Confirm.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_Confirm.Name = "CMD_Confirm";
            this.CMD_Confirm.Size = new System.Drawing.Size(125, 35);
            this.CMD_Confirm.TabIndex = 4;
            this.CMD_Confirm.Text = "Confirm";
            this.CMD_Confirm.UseVisualStyleBackColor = true;
            this.CMD_Confirm.Click += new System.EventHandler(this.CMD_Confirm_Click);
            // 
            // CMD_Cancel
            // 
            this.CMD_Cancel.Location = new System.Drawing.Point(237, 220);
            this.CMD_Cancel.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_Cancel.Name = "CMD_Cancel";
            this.CMD_Cancel.Size = new System.Drawing.Size(125, 35);
            this.CMD_Cancel.TabIndex = 5;
            this.CMD_Cancel.Text = "Cancel";
            this.CMD_Cancel.UseVisualStyleBackColor = true;
            // 
            // LBL_Due
            // 
            this.LBL_Due.AutoSize = true;
            this.LBL_Due.Location = new System.Drawing.Point(168, 18);
            this.LBL_Due.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Due.Name = "LBL_Due";
            this.LBL_Due.Size = new System.Drawing.Size(57, 20);
            this.LBL_Due.TabIndex = 6;
            this.LBL_Due.Text = "label5";
            // 
            // TXT_CardNumber
            // 
            this.TXT_CardNumber.Location = new System.Drawing.Point(173, 58);
            this.TXT_CardNumber.Margin = new System.Windows.Forms.Padding(5);
            this.TXT_CardNumber.Name = "TXT_CardNumber";
            this.TXT_CardNumber.Size = new System.Drawing.Size(164, 26);
            this.TXT_CardNumber.TabIndex = 7;
            // 
            // TXT_CSC
            // 
            this.TXT_CSC.Location = new System.Drawing.Point(173, 149);
            this.TXT_CSC.Margin = new System.Windows.Forms.Padding(5);
            this.TXT_CSC.Name = "TXT_CSC";
            this.TXT_CSC.Size = new System.Drawing.Size(164, 26);
            this.TXT_CSC.TabIndex = 10;
            // 
            // DTP_ExpiryDate
            // 
            this.DTP_ExpiryDate.CustomFormat = "MM/yy";
            this.DTP_ExpiryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DTP_ExpiryDate.Location = new System.Drawing.Point(173, 108);
            this.DTP_ExpiryDate.Name = "DTP_ExpiryDate";
            this.DTP_ExpiryDate.Size = new System.Drawing.Size(70, 26);
            this.DTP_ExpiryDate.TabIndex = 11;
            // 
            // CheckOut
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(738, 438);
            this.Controls.Add(this.DTP_ExpiryDate);
            this.Controls.Add(this.TXT_CSC);
            this.Controls.Add(this.TXT_CardNumber);
            this.Controls.Add(this.LBL_Due);
            this.Controls.Add(this.CMD_Cancel);
            this.Controls.Add(this.CMD_Confirm);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "CheckOut";
            this.Text = "CheckOut";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CheckOut_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button CMD_Confirm;
        private System.Windows.Forms.Button CMD_Cancel;
        private System.Windows.Forms.Label LBL_Due;
        private System.Windows.Forms.TextBox TXT_CardNumber;
        private System.Windows.Forms.TextBox TXT_CSC;
        private System.Windows.Forms.DateTimePicker DTP_ExpiryDate;
    }
}