﻿namespace GCT
{
    partial class CreateNewProduction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateNewProduction));
            this.CMD_Confirm = new System.Windows.Forms.Button();
            this.DTP_End = new System.Windows.Forms.DateTimePicker();
            this.DTP_Start = new System.Windows.Forms.DateTimePicker();
            this.RTB_Description = new System.Windows.Forms.RichTextBox();
            this.TXT_Name = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CMD_Confirm
            // 
            this.CMD_Confirm.Location = new System.Drawing.Point(13, 358);
            this.CMD_Confirm.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_Confirm.Name = "CMD_Confirm";
            this.CMD_Confirm.Size = new System.Drawing.Size(125, 35);
            this.CMD_Confirm.TabIndex = 17;
            this.CMD_Confirm.Text = "Confirm";
            this.CMD_Confirm.UseVisualStyleBackColor = true;
            this.CMD_Confirm.Click += new System.EventHandler(this.CMD_Confirm_Click);
            // 
            // DTP_End
            // 
            this.DTP_End.Location = new System.Drawing.Point(160, 292);
            this.DTP_End.Margin = new System.Windows.Forms.Padding(5);
            this.DTP_End.Name = "DTP_End";
            this.DTP_End.Size = new System.Drawing.Size(221, 26);
            this.DTP_End.TabIndex = 16;
            // 
            // DTP_Start
            // 
            this.DTP_Start.Location = new System.Drawing.Point(160, 240);
            this.DTP_Start.Margin = new System.Windows.Forms.Padding(5);
            this.DTP_Start.Name = "DTP_Start";
            this.DTP_Start.Size = new System.Drawing.Size(221, 26);
            this.DTP_Start.TabIndex = 15;
            // 
            // RTB_Description
            // 
            this.RTB_Description.BackColor = System.Drawing.SystemColors.HotTrack;
            this.RTB_Description.Location = new System.Drawing.Point(160, 49);
            this.RTB_Description.Margin = new System.Windows.Forms.Padding(5);
            this.RTB_Description.Name = "RTB_Description";
            this.RTB_Description.Size = new System.Drawing.Size(312, 142);
            this.RTB_Description.TabIndex = 14;
            this.RTB_Description.Text = "No Description";
            // 
            // TXT_Name
            // 
            this.TXT_Name.BackColor = System.Drawing.SystemColors.HotTrack;
            this.TXT_Name.Location = new System.Drawing.Point(160, 8);
            this.TXT_Name.Margin = new System.Windows.Forms.Padding(5);
            this.TXT_Name.Name = "TXT_Name";
            this.TXT_Name.Size = new System.Drawing.Size(312, 26);
            this.TXT_Name.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 292);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "End Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 240);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Start Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 48);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Description";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Name";
            // 
            // CreateNewProduction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(773, 521);
            this.Controls.Add(this.CMD_Confirm);
            this.Controls.Add(this.DTP_End);
            this.Controls.Add(this.DTP_Start);
            this.Controls.Add(this.RTB_Description);
            this.Controls.Add(this.TXT_Name);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "CreateNewProduction";
            this.Text = "CreateNewProduction";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateNewProduction_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CMD_Confirm;
        private System.Windows.Forms.DateTimePicker DTP_End;
        private System.Windows.Forms.DateTimePicker DTP_Start;
        private System.Windows.Forms.RichTextBox RTB_Description;
        private System.Windows.Forms.TextBox TXT_Name;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}