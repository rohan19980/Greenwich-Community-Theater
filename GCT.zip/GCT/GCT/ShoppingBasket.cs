﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public partial class Shopping_Basket : Form
    {
        public Shopping_Basket(Model model, Form lastForm)
        {
            InitializeComponent();
            this.model = model;

            Owner = lastForm;

            model.CalculateDiscounts();

            for (int i = 0; i < model.Cart.Count(); i++)
            {
                //get current ticket
                model.Ticket = model.Cart[i];

                //Get Performance and select relevent info
                Performance pf = model.GetPerformanceByID(model.Ticket.PerformanceID);

                //Get Production and select relevent info
                int pdIndex = 0;

                for (int j = 0; j < model.Pd.Count(); j++)
                {
                    if (model.Pd[j].ProductionID == pf.ProductionID)
                    {
                        pdIndex = model.Pd.IndexOf(model.Pd[j]);
                    }
                }

                FlowLayoutPanel pnl = new FlowLayoutPanel();
                pnl.Width = FLP_Basket.Width - 20;
                pnl.AutoSize = true;
                pnl.FlowDirection = FlowDirection.TopDown;


                Label LBL_pdName = new Label();
                Label LBL_pfDate = new Label();
                Label LBL_pfTime = new Label();
                Label LBL_seatNo = new Label();
                Label LBL_Age = new Label();
                Label LBL_Price = new Label();

                LBL_pdName.Text = "Production Name: " + model.Pd[pdIndex].ProductionName;
                LBL_pdName.Width = pnl.Width;
                LBL_pfDate.Text = "Performance Date: " + pf.PerformanceDateTime.ToShortDateString();
                LBL_pfDate.Width = pnl.Width;
                LBL_pfTime.Text = "Performance Time: " + pf.PerformanceDateTime.ToShortTimeString();
                LBL_pfTime.Width = pnl.Width;
                LBL_seatNo.Text = "Ticket Seat No: " + model.Ticket.SeatNumber;
                LBL_seatNo.Width = pnl.Width;
                LBL_Age.Text = "Ticket Type: " + model.Ticket.AssignedAgeCategory;
                LBL_Age.Width = pnl.Width;
                LBL_Price.Text = "Ticket Price: " + model.Ticket.SeatCost.ToString("C", CultureInfo.CurrentCulture);
                LBL_Price.Width = pnl.Width;

                LBL_Total.Text = (float.Parse(LBL_Total.Text, NumberStyles.Currency) + model.Ticket.SeatCost).ToString("C", CultureInfo.CurrentCulture);
                Width = FLP_Basket.Width;

                pnl.Controls.Add(LBL_pdName);
                pnl.Controls.Add(LBL_pfDate);
                pnl.Controls.Add(LBL_pfTime);
                pnl.Controls.Add(LBL_seatNo);
                pnl.Controls.Add(LBL_Age);
                pnl.Controls.Add(LBL_Price);


                //add remove button

                Button button = new Button();
                button.Text = "Remove";
                button.Click += (s, ev) =>
                {
                    FLP_Basket.Controls.Remove(pnl);
                    model.Cart.Remove(model.Ticket);

                    LBL_Total.Text = (float.Parse(LBL_Total.Text, NumberStyles.Currency) - model.Ticket.SeatCost).ToString("C", CultureInfo.CurrentCulture);

                    model.UpdateTicketBooked();
                };
                pnl.Controls.Add(button);
                button.Width += 10;

                FLP_Basket.Controls.Add(pnl);
            }
        }

        private Model model;
        private bool checkOutSuccessful = false;
        private string shipmentType = "";
        private double shipmentCost = 0;

        private void CMD_Pay_Click(object sender, EventArgs e)
        {
            if (model.Cart.Count() == 0)
            {
                MessageBox.Show("Please return to the main screen to add tickets");
            }
            else
            {
                if (model.CurrentUser.AccountAccess == 0)
                {
                    //display login? message
                    DialogResult result = MessageBox.Show("You are not logged in, would you like to log in now?", null, MessageBoxButtons.YesNoCancel);
                    if (result == DialogResult.Yes)
                    {
                        Login l = new Login(model, this);
                        l.Show();
                    }
                    else if (result == DialogResult.No)
                    {
                        CreateUser cu = new CreateUser(model, this, true);
                        cu.Show();
                    }
                }
                else if (model.CurrentUser.AccountAccess >= 3)
                {
                    CreateUser cu = new CreateUser(model, this, true);
                    cu.Show();
                }
                else
                {
                    CheckOut co = new CheckOut(model, LBL_Total.Text, shipmentType, shipmentCost);
                    co.Show(this);
                    Hide();
                }
            }
        }

        private void Shopping_Basket_FormClosing(object sender, FormClosingEventArgs e)
        {
            { 
            ReturnView.ViewLastForm(Owner);
            }
        }

        private void ShippingTypeChanged(object sender, EventArgs e)
        {
            //remove previous shipment cost
            shipmentCost = 0;
            RadioButton s = (RadioButton)sender;
            if (s.Text == "1st Class" && !RBT_First.Checked)
            {
                shipmentCost = -1;
            }
            else if (s.Text == "2nd Class" && !RBT_Second.Checked)
            {
                shipmentCost = -0.5;
            }

            LBL_Total.Text = (float.Parse(LBL_Total.Text, NumberStyles.Currency) + shipmentCost).ToString("C", CultureInfo.CurrentCulture);
            shipmentCost = 0;
            //add new shipment cost
            if (s.Text == "1st Class" && RBT_First.Checked)
            {
                shipmentType = "first class";
                shipmentCost = 1;

            }
            else if (s.Text == "2nd Class" && RBT_Second.Checked)
            {
                shipmentType = "second class";
                shipmentCost = 0.50;
            }
            else if (s.Text == "Collect" && RBT_Collect.Checked)
            {
                shipmentType = "collect";
                shipmentCost = 0;
            }

            LBL_Total.Text = (float.Parse(LBL_Total.Text, NumberStyles.Currency) + shipmentCost).ToString("C", CultureInfo.CurrentCulture);
        }

        private void CMD_Cancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
