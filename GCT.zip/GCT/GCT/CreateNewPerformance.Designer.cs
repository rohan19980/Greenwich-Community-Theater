﻿namespace GCT
{
    partial class CreateNewPerformance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateNewPerformance));
            this.CMD_Confirm = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.DTP_Date = new System.Windows.Forms.DateTimePicker();
            this.DTP_Time = new System.Windows.Forms.DateTimePicker();
            this.TXT_BandA = new System.Windows.Forms.TextBox();
            this.TXT_BandB = new System.Windows.Forms.TextBox();
            this.TXT_BandC = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CMD_Confirm
            // 
            this.CMD_Confirm.Location = new System.Drawing.Point(34, 278);
            this.CMD_Confirm.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_Confirm.Name = "CMD_Confirm";
            this.CMD_Confirm.Size = new System.Drawing.Size(125, 35);
            this.CMD_Confirm.TabIndex = 9;
            this.CMD_Confirm.Text = "Confirm";
            this.CMD_Confirm.UseVisualStyleBackColor = true;
            this.CMD_Confirm.Click += new System.EventHandler(this.CMD_Confirm_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 80);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Date:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Time:";
            // 
            // DTP_Date
            // 
            this.DTP_Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTP_Date.Location = new System.Drawing.Point(95, 75);
            this.DTP_Date.Margin = new System.Windows.Forms.Padding(5);
            this.DTP_Date.Name = "DTP_Date";
            this.DTP_Date.Size = new System.Drawing.Size(161, 26);
            this.DTP_Date.TabIndex = 6;
            // 
            // DTP_Time
            // 
            this.DTP_Time.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DTP_Time.Location = new System.Drawing.Point(95, 26);
            this.DTP_Time.Margin = new System.Windows.Forms.Padding(5);
            this.DTP_Time.Name = "DTP_Time";
            this.DTP_Time.ShowUpDown = true;
            this.DTP_Time.Size = new System.Drawing.Size(107, 26);
            this.DTP_Time.TabIndex = 5;
            this.DTP_Time.Value = new System.DateTime(2019, 3, 12, 18, 24, 0, 0);
            // 
            // TXT_BandA
            // 
            this.TXT_BandA.Location = new System.Drawing.Point(169, 122);
            this.TXT_BandA.Name = "TXT_BandA";
            this.TXT_BandA.Size = new System.Drawing.Size(100, 26);
            this.TXT_BandA.TabIndex = 10;
            // 
            // TXT_BandB
            // 
            this.TXT_BandB.Location = new System.Drawing.Point(169, 158);
            this.TXT_BandB.Name = "TXT_BandB";
            this.TXT_BandB.Size = new System.Drawing.Size(100, 26);
            this.TXT_BandB.TabIndex = 11;
            // 
            // TXT_BandC
            // 
            this.TXT_BandC.Location = new System.Drawing.Point(169, 191);
            this.TXT_BandC.Name = "TXT_BandC";
            this.TXT_BandC.Size = new System.Drawing.Size(100, 26);
            this.TXT_BandC.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "Band A Price: £";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Band B Price: £";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Band C Price: £";
            // 
            // CreateNewPerformance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(927, 580);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TXT_BandC);
            this.Controls.Add(this.TXT_BandB);
            this.Controls.Add(this.TXT_BandA);
            this.Controls.Add(this.CMD_Confirm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DTP_Date);
            this.Controls.Add(this.DTP_Time);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "CreateNewPerformance";
            this.Text = "CreateNewPerformance";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateNewPerformance_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CMD_Confirm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker DTP_Date;
        private System.Windows.Forms.DateTimePicker DTP_Time;
        private System.Windows.Forms.TextBox TXT_BandA;
        private System.Windows.Forms.TextBox TXT_BandB;
        private System.Windows.Forms.TextBox TXT_BandC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}