﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCT
{
    public static class VisaCheck
    {
        public static bool CheckCard(double cardNumber, int month, int year, int CSC)
        {
            return true;
        }
    }
}
