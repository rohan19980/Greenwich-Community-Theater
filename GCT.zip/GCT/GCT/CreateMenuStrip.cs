﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    static class CreateMenuStrip
    {
        //make component?
        public static MenuStrip GetMenuStrip(Model model, Form currentForm)
        {
            //create MenuStrip
            MenuStrip ms = new MenuStrip();


            ToolStripMenuItem account = new ToolStripMenuItem("Account");
            account.Alignment = ToolStripItemAlignment.Right;
            if (model.CurrentUser.AccountUsername == "Guest")
            {
                account.DropDownItems.Add("Login", null, Login_Click);
            }
            else
            {
                account.DropDownItems.Add("Switch Account", null, Login_Click);
                account.DropDownItems.Add("Log Out", null, LogOut_Click);
            }

            account.DropDownItems.Add("Register", null, Register_Click);

            ToolStripMenuItem checkout = new ToolStripMenuItem("Checkout", null, Checkout_Click);
            checkout.Alignment = ToolStripItemAlignment.Right;

            ms.Items.Add(checkout);
            ms.Items.Add(account);



            return ms;

            //event listeners
            void Login_Click(object sender, EventArgs e)
            {
                Login l = new Login(model, currentForm);
                l.Show();
                currentForm.Hide();
            }


            void LogOut_Click(object sender, EventArgs e)
            {
                model.GuestLogin();
                currentForm.Hide();
                currentForm.Show();
            }

            void Register_Click(object sender, EventArgs e)
            {
                CreateUser cu = new CreateUser(model, currentForm, false);
                cu.Show();
                currentForm.Hide();
            }

            void Checkout_Click(object sender, EventArgs e)
            {
                Shopping_Basket sb = new Shopping_Basket(model, currentForm);
                sb.Show();
                currentForm.Hide();
            }
        }
    }
}
