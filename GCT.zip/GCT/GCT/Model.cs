﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public class Model
    {
        #region Productions
        private List<Production> pd;
        private int selectedProductionID;

        public List<Production> Pd { get => pd; set => pd = value; }
        public int SelectedProductionID { get => selectedProductionID; set => selectedProductionID = value; }


        public void GetProductions()
        {
            List<Production> pd = Database.Instance.GetAllProductions();

            //Remove productions that have finished running

            for (int i = 0; i < pd.Count(); i++)
            {
                if (pd[i].EndDate < DateTime.Now)
                {
                    pd.Remove(pd[i]);
                    //count is reduced by 1, so reduce index by 1
                    i -= 1;
                }
            }
            this.Pd = pd;
        }

        public List<string> GetProductionNames()
        {
            List<string> pdn = new List<string>();
            if (!(pd.Count() == 0))
            {
                for (int i = 0; i < pd.Count(); i++)
                {
                    pdn.Add(pd[i].ProductionName);
                }
            }

            return pdn;
        }

        //creates new production in Database, stores it in list then returns string to be added to combobox
        public string CreateProduction(string name, string description, DateTime startDate, DateTime endDate)
        {

            pd.Add(Database.Instance.CreateProduction(name, description, startDate, endDate));
            return pd[pd.Count() - 1].ProductionName;
        }
        #endregion

        #region Performances
        List<Performance> pf = new List<Performance>();
        int selectedPerformanceID;
        public List<Performance> Pf { get => pf; set => pf = value; }
        public int SelectedPerformanceID { get => selectedPerformanceID; set => selectedPerformanceID = value; }


        //Gets all performances and returns the Date to be added to the performance combobox
        public void GetPerformances(int productionID)
        {

            List<Performance> pf = Database.Instance.GetAllPerformancesForProduction(productionID);

            for (int i = 0; i < pf.Count(); i++)
            {
                if (pf[i].PerformanceDateTime < DateTime.Now)
                {
                    pf.Remove(pf[i]);
                }
            }

            this.Pf = pf;
        }

        public Performance GetPerformanceByID(int ID)
        {

            return Database.Instance.GetPerformanceByID(ID);
        }

        public List<DateTime> GetProductionDateTimes()
        {
            List<DateTime> pfDateTime = new List<DateTime>();

            for (int i = 0; i < pf.Count(); i++)
            {
                pfDateTime.Add(pf[i].PerformanceDateTime);
            }

            return pfDateTime;

        }

        public void CreatePerformance(int productionID, DateTime pfDateTime, float bandAPrice, float bandBPrice, float bandCPrice)
        {
            pf.Add(Database.Instance.CreatePerformance(productionID, pfDateTime, bandAPrice, bandBPrice, bandCPrice));
        }

        #endregion

        #region Tickets
        private List<Ticket> cart = new List<Ticket>();
        private Ticket ticket;

        public Ticket Ticket { get => ticket; set => ticket = value; }
        public List<Ticket> Cart { get => cart; set => cart = value; }

        public void getTicket(int seatNumber)
        {
            //the seatnumber and performance ID form a composite key

            Ticket = Database.Instance.GetTicket(seatNumber, selectedPerformanceID);
        }


        public void UpdateTicketBooked()
        {
            if (ticket.IsBooked == "Yes")
            {
                Database.Instance.UpdateSeatBooked(ticket.TicketID, "No");
                ticket.IsBooked = "No";
            }
            else
            {
                Database.Instance.UpdateSeatBooked(ticket.TicketID, "Yes", ticket.AssignedAgeCategory);
                ticket.IsBooked = "Yes";
            }
        }

        public void OrderTickets(int orderID)
        {
            foreach (Ticket t in cart)
            {
                t.OrderID = orderID;
                Database.Instance.UpdateSeatOwner(t.TicketID, orderID);
            }
        }

        public List<string> GetAllBookedSeats(int pfID)
        {
            return Database.Instance.GetAllBookedSeats(pfID);
        }


        #endregion

        #region Account
        private Account currentUser;
        public Account CurrentUser { get => currentUser; set => currentUser = value; }


        public void CreateAccount(string firstName, string lastName, string email, string username, string password, string address, string phone, int access)
        {

            //user has to login after registering
            //check username does not already exist
            if (Database.Instance.CheckUsername(username) == false)
            {
                Database.Instance.CreateAccount(firstName, lastName, email, username, password, address, phone, access);
            }
            else
            {
                MessageBox.Show("username Taken");
            }
        }

        public void CreateAccount(string firstName, string lastName, string email, string address, string phone)
        {

            Database.Instance.CreateAccount(firstName, lastName, email, address, phone);
        }

        public void Login(string username, string password)
        {


            if (Database.Instance.CheckLogin(username, password) == true)
            {
                CurrentUser = Database.Instance.GetAccount(username);
            }
            else
            {
                MessageBox.Show("Incorrect Username or Password");
            }
        }

        public void GuestLogin()
        {
            Login("Guest", "None");
        }
        #endregion

        #region Reviews
        List<Review> reviews = new List<Review>();
        public List<Review> Reviews { get => reviews; set => reviews = value; }



        public void GetReviews(int pdID)
        {

            Reviews = Database.Instance.GetReviews(pdID);
        }

        public void CreateReview(string data, int pdID, int accID)
        {

            Reviews.Add(Database.Instance.CreateReview(data, pdID, accID));
        }

        #endregion

        #region Order
        public void CreateOrder(DateTime date, double cost, double cardNumber, int accountID, string shippingType, double shippingCost)
        {
            cost = double.Parse(cost.ToString("0.00"));
            int ID = Database.Instance.CreateOrder(date, cost, cardNumber, accountID, shippingType, shippingCost);
            OrderTickets(ID);
        }

        public void CalculateDiscounts()
        {
            int i = 0;
            //return total discount?

            foreach (Ticket t in Cart)
            {
                i++;
                if (i == 5)
                {
                    t.SeatCost = 0;
                    i = 0;
                }
                else
                {

                    if (GetPerformanceByID(t.PerformanceID).PerformanceDateTime.AddHours(-1) < DateTime.Now)
                    {
                        t.SeatCost *= (float)0.9;
                    }

                    if (CurrentUser.AccountAccess == 1)
                    {
                        t.SeatCost *= (float)0.95;
                        if (Cart.Count() > 20)
                        {
                            t.SeatCost *= (float)0.95;
                        }
                    }

                    if (t.AssignedAgeCategory == "Child" || t.AssignedAgeCategory == "OAP")
                    {
                        t.SeatCost *= (float) 0.75;
                    }
                }
                t.SeatCost = float.Parse(t.SeatCost.ToString("0.00"));
            }



        }
        #endregion
    }
}
