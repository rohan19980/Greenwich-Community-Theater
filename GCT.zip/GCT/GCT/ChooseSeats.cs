﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public partial class ChooseSeats : Form
    {
        public ChooseSeats(Model model)
        {
            InitializeComponent();
            this.model = model;

            List<string> bookedSeats = model.GetAllBookedSeats(model.SelectedPerformanceID);

            foreach (Button b in Controls.OfType<Button>())
            {
                if (bookedSeats.Contains(b.Text))
                {
                    b.BackColor = Color.Red;
                }
            }
        }

        private void ChooseSeats_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < model.Cart.Count(); i++)
            {
                if (model.Cart[i].PerformanceID == model.SelectedPerformanceID)
                {
                    model.Ticket = model.Cart[i];
                    AddSeatToCart();
                }
            }
        }

        private void ChooseSeats_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                Controls.Add(CreateMenuStrip.GetMenuStrip(model, this));
            }
            else
            {
                foreach (Control c in Controls)
                {
                    if (c.GetType() == typeof(MenuStrip))
                    {
                        Controls.Remove(c);
                    }
                }
            }
        }

        private Model model;
        private int selectedSeat;
        private bool saveSelection = false;

        private void ChangeSelectedSeat(int s)
        {
            TXT_SelectedSeat.Text = "Selected Seat: " + s;
            selectedSeat = s;
        }

        private void CMD_AddToCart_Click(object sender, EventArgs e)
        {
            if (TXT_SelectedSeat.Text != "")
            {
                if (RBT_Under12.Checked == false && RBT_Adult.Checked == false && RBT_OAP.Checked == false)
                {
                    MessageBox.Show("An age must be selected");
                }
                else
                {
                    //check if ticket is booked? (can be moved to earlier in run)
                    model.getTicket(selectedSeat);
                    //if ticket is not booked, add to cart
                    if (model.Ticket.IsBooked == "No" && !model.Cart.Contains(model.Ticket))
                    {
                        //add ticket to shopping list
                        model.Cart.Add(model.Ticket);
                        AddSeatToCart();
                        model.UpdateTicketBooked();
                    }
                    else
                    {
                        MessageBox.Show("Seat Booked");
                    }
                }
            }
        }

        private void AddSeatToCart()
        {
            float seatPrice = model.Ticket.SeatCost;

            if (RBT_Under12.Checked)
            {
                model.Ticket.AssignedAgeCategory = "Child";
                seatPrice *= (float) 0.75;
            }
            else if (RBT_Adult.Checked)
            {
                model.Ticket.AssignedAgeCategory = "Adult";
            } 
            else
            {
                model.Ticket.AssignedAgeCategory = "OAP";
                seatPrice *= (float)0.75;
            }

            Label lbl1 = new Label();
            lbl1.Text = "Seat No. : " + model.Ticket.SeatNumber;
            lbl1.Width = FLP_Cart.Width - 10;
            FLP_Cart.Controls.Add(lbl1);

            Label lbl2 = new Label();
            lbl2.Text = "Ticket Type: " + model.Ticket.AssignedAgeCategory;
            lbl2.Width = FLP_Cart.Width - 10;
            FLP_Cart.Controls.Add(lbl2);

            Label lbl3 = new Label();
            lbl3.Text = "Cost: " + seatPrice.ToString("C", CultureInfo.CurrentCulture);
            lbl3.Width = FLP_Cart.Width - 10;
            FLP_Cart.Controls.Add(lbl3);

            //remove from shopping cart
            Button button = new Button();
            button.Text = "Remove";
            button.Click += (s, ev) =>
            {
                model.Cart.Remove(model.Ticket);
                FLP_Cart.Controls.Remove(button);
                FLP_Cart.Controls.Remove(lbl1);
                FLP_Cart.Controls.Remove(lbl2);
                FLP_Cart.Controls.Remove(lbl3);
                LBL_TotalVal.Text = (float.Parse(LBL_TotalVal.Text, NumberStyles.Currency) - seatPrice).ToString("C", CultureInfo.CurrentCulture);

                model.UpdateTicketBooked();
            };
            button.Width += 10;
            FLP_Cart.Controls.Add(button);
            LBL_TotalVal.Text = (float.Parse(LBL_TotalVal.Text, NumberStyles.Currency) + seatPrice).ToString("C", CultureInfo.CurrentCulture);
        }


        #region Select Seat Buttons
        private void CMD_1_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(1);
        }

        private void CMD_2_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(2);
        }

        private void CMD_3_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(3);
        }

        private void CMD_4_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(4);
        }

        private void CMD_5_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(5);
        }

        private void CMD_6_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(6);
        }

        private void CMD_7_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(7);
        }

        private void CMD_8_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(8);
        }

        private void CMD_9_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(9);
        }

        private void CMD_10_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(10);
        }

        private void CMD_11_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(11);
        }

        private void CMD_12_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(12);
        }

        private void CMD_13_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(13);
        }

        private void CMD_14_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(14);
        }

        private void CMD_15_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(15);
        }

        private void CMD_16_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(16);
        }

        private void CMD_17_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(17);
        }

        private void CMD_18_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(18);
        }

        private void CMD_19_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(19);
        }

        private void CMD_20_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(20);
        }

        private void CMD_21_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(21);
        }

        private void CMD_22_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(22);
        }

        private void CMD_23_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(23);
        }

        private void CMD_24_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(24);
        }

        private void CMD_25_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(25);
        }

        private void CMD_26_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(26);
        }

        private void CMD_27_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(27);
        }

        private void CMD_28_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(28);
        }

        private void CMD_29_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(29);
        }

        private void CMD_30_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(30);
        }

        private void CMD_31_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(31);
        }

        private void CMD_32_Click(object sender, EventArgs e)
        {
            ChangeSelectedSeat(32);
        }
        #endregion

        private void CMD_Accept_Click(object sender, EventArgs e)
        {
            if (selectedSeat != 0)
            {
                saveSelection = true;
                Close();
            }
        }

        private void CMD_Cancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ChooseSeats_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (saveSelection == false)
            {
                for (int i = 0; i < model.Cart.Count(); i++)
                {
                    model.Ticket = model.Cart[i];

                    if (model.Ticket.PerformanceID == model.SelectedPerformanceID)
                    {
                        model.UpdateTicketBooked();
                        model.Cart.RemoveAt(i);
                        i -= 1;
                    }
                }
            }

            ReturnView.ViewLastForm(Owner);
        }


    }
}
