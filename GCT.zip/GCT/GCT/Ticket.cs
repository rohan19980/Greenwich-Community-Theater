﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCT
{
    public class Ticket
    {
        private int ticketID;
        private int seatNumber;
        private int orderID;
        private float seatCost;
        private int performanceID;
        private string isBooked;
        private string assignedAgeCategory;

        public Ticket(int tID, int sNum, int oID, float c, int pfID, string booked, string ageCategory)
        {
            ticketID = tID;
            seatNumber = sNum;
            OrderID = oID;
            seatCost = c;
            PerformanceID = pfID;
            isBooked = booked;
            AssignedAgeCategory = ageCategory;
        }

        public int TicketID { get => ticketID; set => ticketID = value; }
        public int SeatNumber { get => seatNumber; set => seatNumber = value; }
        public int OrderID { get => orderID; set => orderID = value; }
        public float SeatCost { get => seatCost; set => seatCost = value; }
        public int PerformanceID { get => performanceID; set => performanceID = value; }
        public string IsBooked { get => isBooked; set => isBooked = value; }
        public string AssignedAgeCategory { get => assignedAgeCategory; set => assignedAgeCategory = value; }
    }
}
