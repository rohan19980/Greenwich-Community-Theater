﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public sealed class Database
    {
        #region Singleton
        private static Database instance = null;
        private Database() { }

        public static Database Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Database();
                }
                return instance;
            }
        }


        #endregion



        private OleDbConnection createConnection()
        {
            String connString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=|DataDirectory|GreenwichCommuntyTheatre.mdb";  //change to new name
            OleDbConnection myConnection = new OleDbConnection(connString);

            return myConnection;
        }

        #region SQL
        #region Productions
        public List<Production> GetAllProductions()
        {
                List<List<string>> values = getAllRows("SELECT * FROM Production", 5);
                List<Production> pd = new List<Production>();

                for (int i = 0; i < values.Count(); i++)
                {
                    pd.Add(new Production(int.Parse(values[i][0]), values[i][1], values[i][2], DateTime.Parse(values[i][3]), DateTime.Parse(values[i][4])));
                }

                return pd;
        }

        public Production CreateProduction(string name, string description, DateTime startDate, DateTime endDate)
        {
            int ID = outputData("INSERT INTO Production (ProductionName, Description, StartDate, EndDate) VALUES ('" + name + "','" + description + "','" + startDate + "','" + endDate + "')");
            return new Production(ID, name, description, startDate, endDate);
        }
        #endregion

        #region performances
        public List<Performance> GetAllPerformancesForProduction(int productionID)
        {
            List<List<string>> values = new List<List<string>>();
            List<Performance> pf = new List<Performance>();

            values = getAllRows("SELECT * FROM Performance WHERE ProductionID = " + productionID, 3);

            for (int i = 0; i < values.Count(); i++)
            {
                pf.Add(new Performance(int.Parse(values[i][0]), int.Parse(values[i][1]), DateTime.Parse(values[i][2])));
            }

            return pf;
        }

        public Performance GetPerformanceByID(int ID)
        {
            List<List<string>> values = new List<List<string>>();
            Performance pf;

            values = getAllRows("SELECT * FROM Performance WHERE PerformanceID = " + ID, 3);
            pf = new Performance(int.Parse(values[0][0]), int.Parse(values[0][1]), DateTime.Parse(values[0][2]));

            return pf;
        }

        public Performance CreatePerformance(int productionID, DateTime performanceDateTime, float bandA, float bandB, float bandC)
        {
            //returns new ID
            int ID = outputData("INSERT INTO Performance (ProductionID, PerformanceDateTime) VALUES (" + productionID + ",'" + performanceDateTime + "')");
            Performance pf = new Performance(ID, productionID, performanceDateTime);

            //create ticket for each seat in the performance
            float cost = 0;
            for (int i = 1; i <= 32; i++)
            {
                if (i > 0 && i <= 12)
                {
                    cost = bandA;
                }
                else if ((i >= 13 && i <= 18) || (i >= 21 && i <= 23))
                {
                    cost = bandB;
                }
                else
                {
                    cost = bandC;
                }
                outputData("INSERT INTO Ticket (OrderID, SeatNumber, Cost, PerformanceID, IsBooked) VALUES (Null," + i + "," + cost + "," + ID + ",'" + "No')");
            }

            return pf;

        }
        #endregion

        #region Tickets
        public Ticket GetTicket(int seatNumber, int performanceID)
        {
            Ticket T;
            List<string> columns = new List<string>();

            columns.Add("TicketID");
            columns.Add("SeatNumber");
            columns.Add("OrderID");
            columns.Add("Cost");
            columns.Add("PerformanceID");
            columns.Add("IsBooked");
            columns.Add("AgeCategory");

            List<string> values = getRow("SELECT * FROM Ticket WHERE SeatNumber = " + seatNumber + " AND PerformanceID = " + performanceID, columns);

            //if these values have not yet been set, give them a temporary value

            if (values[2] == "")
            {
                values[2] = 0.ToString();
            }

            T = new Ticket(int.Parse(values[0]), int.Parse(values[1]), int.Parse(values[2]), float.Parse(values[3]), int.Parse(values[4]), values[5], values[6]);

            return T;
        }

        public void UpdateSeatBooked(int ticketID, string change)
        {
            updateValue("UPDATE Ticket SET IsBooked = '" + change + "' WHERE TicketID = " + ticketID);
        }

        public void UpdateSeatBooked(int ticketID, string change, string ageCategory)
        {
            updateValue("UPDATE Ticket SET IsBooked = '" + change + "', AgeCategory = '" + ageCategory + "' WHERE TicketID = " + ticketID);
        }

        public void UpdateSeatOwner(int ticketID, int orderID)
        {
            updateValue("UPDATE Ticket SET OrderID = " + orderID + " WHERE TicketID = " + ticketID);
        }

        public  List<string> GetAllBookedSeats(int pfID)
        {
            return getRow("SELECT * FROM Ticket WHERE PerformanceID = " + pfID + "AND IsBooked = 'Yes'", new List<string>() { "SeatNumber" });
        }

        #endregion

        #region Accounts

        public Account GetAccount(string username)
        {
            List<string> columns = new List<string>();

            columns.Add("Account.AccountID");
            columns.Add("FirstName");
            columns.Add("LastName");
            columns.Add("Email");
            columns.Add("Username");
            columns.Add("Password");
            columns.Add("Address");
            columns.Add("Phone");
            columns.Add("AccountAccess");

            List<string> values =  getRow("SELECT * FROM Login INNER JOIN Account ON Account.AccountID = Login.AccountID WHERE Username = '" + username + "'", columns);

            return new Account(int.Parse(values[0]), values[1], values[2], values[3], values[4], values[5], values[6], values[7], int.Parse(values[8]));
        }

        public void CreateAccount(string firstName, string lastName, string userEmail, string address, string contactNumber)
        {
            CreateUser(firstName, lastName, userEmail, address, contactNumber, 0);
        }

        public void CreateAccount(string firstName, string lastName, string userEmail, string username, string password, string address, string contactNumber, int accountAccess)
        { 
            //see if username already exists
            if (CheckUsername(username) == false)
            {
                int ID = CreateUser(firstName, lastName, userEmail, address, contactNumber, accountAccess);
                outputData("INSERT INTO Login (AccountID, Username, [Password]) Values (" + ID + ",'" + username + "','" + password + "')");
            }
        }

        //write just to user table
        private int CreateUser(string firstName, string lastName, string userEmail, string address, string contactNumber, int accountAccess)
        {
            return outputData("INSERT INTO Account (FirstName, LastName, Email, Address, Phone, AccountAccess) Values ('" + firstName + "','" + lastName + "','" + userEmail + "','" + address + "','" + contactNumber + "'," + accountAccess + ")");
        }

        public bool CheckUsername(string username)
        {
            return checkValueExists("SELECT Count(*) FROM Login WHERE username = '" + username + "'");
        }

        public bool CheckLogin(string username, string password)
        {
            bool check = false;

            //if the username and password are correct
            if (CheckUsername(username) == true)
            {
                if (getRow("SELECT Password FROM Login WHERE Username = '" + username + "'", new List<string>() { "Password" })[0] == password)
                {
                    check = true;
                }
            }
            return check;
        }
        #endregion

        #region Reviews
        public List<Review> GetReviews(int pdID)
        {
            List<List<string>> values = getAllRows("SELECT * FROM Review", 4);
            List<Review> rv = new List<Review>();

            for (int i = 0; i < values.Count(); i++)
            {
                rv.Add(new Review(int.Parse(values[i][0]), values[i][1], int.Parse(values[i][2]), int.Parse(values[i][3])));
            }

            return rv;
        }

        public Review CreateReview(string data, int pdID, int accID)
        {
            int ID = outputData("INSERT INTO Review (ReviewData, ProductionID, CustomerID) Values ('" + data + "'," + pdID + "," + accID + ")");
            return new Review(ID, data, pdID, accID);
        }
        #endregion

        #region Orders

        public int CreateOrder(DateTime date, double cost, double cardNumber, int accountID, string shippingType, double shippingCost)
        {
            int ID = outputData("INSERT INTO [Order] (AccountID, CardNumber, TotalCost, OrderDate, ShippingType, ShippingCost) VALUES (" + accountID + "," + cardNumber.ToString() + "," + cost + ",'" + date + "','" + shippingType + "'," + shippingCost + ")");
            return ID;
        } 

        #endregion
        #endregion

        #region SendToDatabase
        private int outputData(string SQL)
        {
            int ID = 0;
            OleDbConnection myConnection = createConnection();
            OleDbCommand myCommand = new OleDbCommand(SQL, myConnection);
            //gets ID of added record
            OleDbCommand getID = new OleDbCommand("Select @@Identity", myConnection);

            try
            {
                myConnection.Open();

                //Add new row
                myCommand.ExecuteNonQuery();
                //gets ID of row
                ID = (int)getID.ExecuteScalar();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                myConnection.Close();
            }
            return ID;
        }

        private List<List<string>> getAllRows(String SQL, int noColumns)
        {
            List<List<String>> allValues = new List<List<String>>();
            List<String> values = new List<String>();

            OleDbConnection myConnection = createConnection();
            OleDbCommand myCommand = new OleDbCommand(SQL, myConnection);

            try
            {
                myConnection.Open();

                OleDbDataReader myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    for (int i = 0; i < noColumns; i++)
                    {
                        values.Add(myReader[i].ToString());
                    }
                    allValues.Add(values.ToList());

                    values.Clear();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                myConnection.Close();
            }

            return allValues;
        }

        private List<string> getRow(string SQL, List<string> column)
        {
            List<string> values = new List<string>();

            OleDbConnection myConnection = createConnection();
            OleDbCommand myCommand = new OleDbCommand(SQL, myConnection);

            try
            {
                myConnection.Open();

                OleDbDataReader myReader = myCommand.ExecuteReader();

                while (myReader.Read())
                {
                    for (int i = 0; i < column.Count(); i++)
                    {
                        values.Add(myReader[column[i]].ToString());
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                myConnection.Close();
            }

            return values;
        }

        private void updateValue(string SQL)
        {
            OleDbConnection myConnection = createConnection();
            OleDbCommand myCommand = new OleDbCommand(SQL, myConnection);

            try
            {
                myConnection.Open();
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }


        }

        private bool checkValueExists(string SQL)
        {
            OleDbConnection myConnection = createConnection();
            OleDbCommand myCommand = new OleDbCommand(SQL, myConnection);

            try
            {
                myConnection.Open();

                int i = int.Parse(myCommand.ExecuteScalar().ToString());
                //Find value
                if (int.Parse(myCommand.ExecuteScalar().ToString()) != 0)
                {
                    return true;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                myConnection.Close();
            }

            return false;
        }
        #endregion


    }
}
