﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public partial class Login : Form
    {
        public Login(Model model, Form currentForm)
        {
            InitializeComponent();
            this.model = model;
            Owner = currentForm;
        }

        Model model;

        private void CMD_Login_Click(object sender, EventArgs e)
        {
            model.Login(TXT_Username.Text, TXT_Password.Text);
            Close();
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            ReturnView.ViewLastForm(Owner);
        }
    }
}
