﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public partial class CreateNewProduction : Form
    {
        private Model model;

        public CreateNewProduction(Model model)
        {
            InitializeComponent();
            this.model = model;
        }

        private void CMD_Confirm_Click(object sender, EventArgs e)
        {
            if (TXT_Name.Text == "")
            {
                MessageBox.Show("Please enter the production name");
            }
            else if (DTP_Start.Value < DateTime.Now || DTP_End.Value < DateTime.Now)
            {
                MessageBox.Show("The start and end dates cannot be in the past");
            }
            else
            {
                model.CreateProduction(TXT_Name.Text, RTB_Description.Text, DateTime.Parse(DTP_Start.Text), DateTime.Parse(DTP_End.Text));

                ChooseShow cs = (ChooseShow)Owner;
                cs.UpdateProductionCBX(TXT_Name.Text);
                cs.Show();

                Close();
            }
        }

        private void CreateNewProduction_FormClosing(object sender, FormClosingEventArgs e)
        {
            ReturnView.ViewLastForm(Owner);
        }
    }
}
