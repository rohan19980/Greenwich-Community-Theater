﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public static class ReturnView
    {
        public static void ViewLastForm(Form form)
        {
            if (form.GetType() == typeof(ChooseShow))
            {
                ChooseShow cs = (ChooseShow)form;
                cs.Show();
            }
            else if (form.GetType() == typeof(ChooseSeats))
            {
                ChooseSeats cs = (ChooseSeats)form;
                cs.Show();
            }
            else if (form.GetType() == typeof(ShowReviews))
            {
                ShowReviews sr = (ShowReviews)form;
                sr.Show();
            }
            else if (form.GetType() == typeof(Shopping_Basket))
            {
                Shopping_Basket sb = (Shopping_Basket)form;
                sb.Show();
            }
        }
    }
}
