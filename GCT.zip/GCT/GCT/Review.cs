﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCT
{
    public class Review
    {
        private int reviewID;
        private string reviewData;
        private int productionID;
        private int accountID;

        public Review(int ID, string data, int pdID, int accID)
        {
            reviewID = ID;
            reviewData = data;
            productionID = pdID;
            accountID = accID;
        }

        public int ReviewID { get => reviewID; set => reviewID = value; }
        public string ReviewData { get => reviewData; set => reviewData = value; }
        public int ProductionID { get => productionID; set => productionID = value; }
        public int AccountID { get => AccountID; set => AccountID = value; }
    }
}
