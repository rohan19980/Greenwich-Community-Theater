﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCT
{
    public partial class ChooseShow : Form
    {
        public ChooseShow(Model model)
        {
            InitializeComponent();
            this.model = model;
        }

        private Boolean isLoaded;
        private Model model;

        //recreates form base on user's access level
        private void ChooseShow_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                if (model.CurrentUser.AccountAccess <= 2)
                {
                    CMD_CreatePerformance.Hide();
                    CMD_CreateProduction.Hide();
                }
                else
                {
                    CMD_CreatePerformance.Show();
                    CMD_CreateProduction.Show();
                }
                Controls.Add(CreateMenuStrip.GetMenuStrip(model, this));
            }
            else
            {
                foreach (Control c in Controls) {
                    if (c.GetType() == typeof(MenuStrip))
                    {
                        Controls.Remove(c);
                    }
                }
            }
        }



        #region Productions
        private void ChooseShow_Load(object sender, EventArgs e)
        {
            model.GuestLogin();
            model.GetProductions();
            List<string> pdName = model.GetProductionNames();

            int stringWidth = 0;
            int longestWidth = 1;
            Font font = CBX_Productions.Font;
            Graphics g = CBX_Productions.CreateGraphics();

            for (int i = 0; i < pdName.Count(); i++)
            {
                CBX_Productions.Items.Add(pdName[i]);
                stringWidth = (int) g.MeasureString(pdName[i], font).Width;

                if (stringWidth > longestWidth)
                {
                    longestWidth = stringWidth;
                }
            }

            CBX_Productions.DropDownWidth = longestWidth + 2;

            //this is required to set the selected index
            //as the combobox is filled during form load, 
            //the first time an item is clicked, the form reloads and returns a value of -1
            try
            {
                CBX_Productions.SelectedIndex = 1;
                CBX_Productions.SelectedIndex = 0;
            }
            catch { };

            DisplayProductionInfo();
        }

        private void DisplayProductionInfo()
        {
            RTB_ProductionInfo.Text = "Name: " + model.Pd[CBX_Productions.SelectedIndex].ProductionName;
            RTB_ProductionInfo.AppendText(Environment.NewLine + "Description: " + model.Pd[CBX_Productions.SelectedIndex].Description);
            RTB_ProductionInfo.AppendText(Environment.NewLine + "Start Date: " + model.Pd[CBX_Productions.SelectedIndex].StartDate.ToShortDateString());
            RTB_ProductionInfo.AppendText(Environment.NewLine + "End Date: " + model.Pd[CBX_Productions.SelectedIndex].EndDate.ToShortDateString());
        }

        private void CMD_CreateProduction_Click(object sender, EventArgs e)
        {
            CreateNewProduction np = new CreateNewProduction(model);
            np.Show(this);
            this.Hide();
        }

        public void UpdateProductionCBX(string name)
        {
            CBX_Productions.Items.Add(name);
        }
        #endregion

        #region Performances
        private void CBX_Productions_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplayProductionInfo();
            model.SelectedProductionID = model.Pd[CBX_Productions.SelectedIndex].ProductionID;

            if (!isLoaded)
            {
                isLoaded = true;
            }
            else
            {
                CBX_Performance.Items.Clear();
                //set global performance list in model to new performances
                model.GetPerformances(model.Pd[CBX_Productions.SelectedIndex].ProductionID);


                
                for (int i = 0; i < model.Pf.Count(); i++)
                {
                    CBX_Performance.Items.Add(model.Pf[i].PerformanceDateTime.ToShortTimeString() + "   " + model.Pf[i].PerformanceDateTime.ToShortDateString());
                }

                try
                {
                    CBX_Performance.SelectedIndex = 0;
                }
                catch 
                {
                    CBX_Performance.Text = "";
                    CBX_Performance.SelectedIndex = -1;
                    MessageBox.Show("Sorry, no performances are scheduled for that show");
                }   
            }
        }

        private void CMD_CreatePerformance_Click(object sender, EventArgs e)
        {
            CreateNewPerformance np = new CreateNewPerformance(model.Pd[CBX_Productions.SelectedIndex].ProductionID, model);
            np.Show(this);
            this.Hide();
        }

        public void UpdatePerformanceCBX(DateTime dt)
        {
            CBX_Performance.Items.Add(dt.ToShortTimeString() + "   " +dt.ToShortDateString());
        }

        private void CBX_Performance_SelectedIndexChanged(object sender, EventArgs e)
        {
            model.SelectedPerformanceID = model.Pf[CBX_Performance.SelectedIndex].PerformacneID;
        }

        #endregion

        private void CMD_Select_Click(object sender, EventArgs e)
        {
            if (!(CBX_Performance.Text == "")) {
                //tells the model which performanceID has been chosen to be used when booking tickets.  
                ChooseSeats cs = new ChooseSeats(model);
                cs.Show(this);
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please select a performance");
            }
        }

        private void LLBL_Reviews_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ShowReviews sr = new ShowReviews(model);
            sr.Show(this);
            this.Hide();
        }

        private void ChooseShow_FormClosing(object sender, FormClosingEventArgs e)
        {

            while (model.Cart.Count > 0)
            {
                model.Ticket = model.Cart[0];
                model.UpdateTicketBooked();

                model.Cart.RemoveAt(0);
            }
        }
    }
}
