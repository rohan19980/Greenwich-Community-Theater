﻿namespace GCT
{
    partial class ShowReviews
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShowReviews));
            this.RTB_NewReview = new System.Windows.Forms.RichTextBox();
            this.CMD_AddReview = new System.Windows.Forms.Button();
            this.CMD_Close = new System.Windows.Forms.Button();
            this.FLP_Reviews = new System.Windows.Forms.FlowLayoutPanel();
            this.SuspendLayout();
            // 
            // RTB_NewReview
            // 
            this.RTB_NewReview.Location = new System.Drawing.Point(14, 465);
            this.RTB_NewReview.Margin = new System.Windows.Forms.Padding(5);
            this.RTB_NewReview.Name = "RTB_NewReview";
            this.RTB_NewReview.Size = new System.Drawing.Size(705, 101);
            this.RTB_NewReview.TabIndex = 0;
            this.RTB_NewReview.Text = "";
            // 
            // CMD_AddReview
            // 
            this.CMD_AddReview.Location = new System.Drawing.Point(14, 590);
            this.CMD_AddReview.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_AddReview.Name = "CMD_AddReview";
            this.CMD_AddReview.Size = new System.Drawing.Size(125, 35);
            this.CMD_AddReview.TabIndex = 2;
            this.CMD_AddReview.Text = "Add Review";
            this.CMD_AddReview.UseVisualStyleBackColor = true;
            this.CMD_AddReview.Click += new System.EventHandler(this.CMD_AddReview_Click);
            // 
            // CMD_Close
            // 
            this.CMD_Close.Location = new System.Drawing.Point(14, 649);
            this.CMD_Close.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_Close.Name = "CMD_Close";
            this.CMD_Close.Size = new System.Drawing.Size(125, 35);
            this.CMD_Close.TabIndex = 3;
            this.CMD_Close.Text = "Close";
            this.CMD_Close.UseVisualStyleBackColor = true;
            this.CMD_Close.Click += new System.EventHandler(this.CMD_Close_Click);
            // 
            // FLP_Reviews
            // 
            this.FLP_Reviews.AutoScroll = true;
            this.FLP_Reviews.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.FLP_Reviews.Location = new System.Drawing.Point(14, 57);
            this.FLP_Reviews.Name = "FLP_Reviews";
            this.FLP_Reviews.Size = new System.Drawing.Size(705, 400);
            this.FLP_Reviews.TabIndex = 4;
            this.FLP_Reviews.WrapContents = false;
            // 
            // ShowReviews
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(733, 698);
            this.Controls.Add(this.FLP_Reviews);
            this.Controls.Add(this.CMD_Close);
            this.Controls.Add(this.CMD_AddReview);
            this.Controls.Add(this.RTB_NewReview);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "ShowReviews";
            this.Text = "ShowReviews";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ShowReviews_FormClosing);
            this.VisibleChanged += new System.EventHandler(this.ShowReviews_VisibleChanged);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RTB_NewReview;
        private System.Windows.Forms.Button CMD_AddReview;
        private System.Windows.Forms.Button CMD_Close;
        private System.Windows.Forms.FlowLayoutPanel FLP_Reviews;
    }
}