﻿namespace GCT
{
    partial class CreateUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateUser));
            this.TXT_UserName = new System.Windows.Forms.TextBox();
            this.TXT_Password = new System.Windows.Forms.TextBox();
            this.TXT_FirstName = new System.Windows.Forms.TextBox();
            this.TXT_Email = new System.Windows.Forms.TextBox();
            this.TXT_Address = new System.Windows.Forms.TextBox();
            this.TXT_PhoneNumber = new System.Windows.Forms.TextBox();
            this.CMD_Submit = new System.Windows.Forms.Button();
            this.LBL_Phone = new System.Windows.Forms.Label();
            this.LBL_Address = new System.Windows.Forms.Label();
            this.LBL_Email = new System.Windows.Forms.Label();
            this.LBL_FirstName = new System.Windows.Forms.Label();
            this.LBL_Password = new System.Windows.Forms.Label();
            this.LBL_Username = new System.Windows.Forms.Label();
            this.TXT_LastName = new System.Windows.Forms.TextBox();
            this.LBL_LastName = new System.Windows.Forms.Label();
            this.LBL_Type = new System.Windows.Forms.Label();
            this.CBX_AccountType = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // TXT_UserName
            // 
            this.TXT_UserName.Location = new System.Drawing.Point(157, 26);
            this.TXT_UserName.Margin = new System.Windows.Forms.Padding(5);
            this.TXT_UserName.Name = "TXT_UserName";
            this.TXT_UserName.Size = new System.Drawing.Size(164, 26);
            this.TXT_UserName.TabIndex = 25;
            // 
            // TXT_Password
            // 
            this.TXT_Password.Location = new System.Drawing.Point(157, 66);
            this.TXT_Password.Margin = new System.Windows.Forms.Padding(5);
            this.TXT_Password.Name = "TXT_Password";
            this.TXT_Password.PasswordChar = '*';
            this.TXT_Password.Size = new System.Drawing.Size(164, 26);
            this.TXT_Password.TabIndex = 24;
            // 
            // TXT_FirstName
            // 
            this.TXT_FirstName.Location = new System.Drawing.Point(157, 103);
            this.TXT_FirstName.Margin = new System.Windows.Forms.Padding(5);
            this.TXT_FirstName.Name = "TXT_FirstName";
            this.TXT_FirstName.Size = new System.Drawing.Size(164, 26);
            this.TXT_FirstName.TabIndex = 23;
            // 
            // TXT_Email
            // 
            this.TXT_Email.Location = new System.Drawing.Point(157, 183);
            this.TXT_Email.Margin = new System.Windows.Forms.Padding(5);
            this.TXT_Email.Name = "TXT_Email";
            this.TXT_Email.Size = new System.Drawing.Size(164, 26);
            this.TXT_Email.TabIndex = 22;
            // 
            // TXT_Address
            // 
            this.TXT_Address.Location = new System.Drawing.Point(157, 223);
            this.TXT_Address.Margin = new System.Windows.Forms.Padding(5);
            this.TXT_Address.Name = "TXT_Address";
            this.TXT_Address.Size = new System.Drawing.Size(164, 26);
            this.TXT_Address.TabIndex = 21;
            // 
            // TXT_PhoneNumber
            // 
            this.TXT_PhoneNumber.Location = new System.Drawing.Point(157, 263);
            this.TXT_PhoneNumber.Margin = new System.Windows.Forms.Padding(5);
            this.TXT_PhoneNumber.Name = "TXT_PhoneNumber";
            this.TXT_PhoneNumber.Size = new System.Drawing.Size(164, 26);
            this.TXT_PhoneNumber.TabIndex = 20;
            // 
            // CMD_Submit
            // 
            this.CMD_Submit.Location = new System.Drawing.Point(20, 380);
            this.CMD_Submit.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_Submit.Name = "CMD_Submit";
            this.CMD_Submit.Size = new System.Drawing.Size(125, 35);
            this.CMD_Submit.TabIndex = 19;
            this.CMD_Submit.Text = "OK";
            this.CMD_Submit.UseVisualStyleBackColor = true;
            this.CMD_Submit.Click += new System.EventHandler(this.CMD_Submit_Click);
            // 
            // LBL_Phone
            // 
            this.LBL_Phone.AutoSize = true;
            this.LBL_Phone.Location = new System.Drawing.Point(13, 268);
            this.LBL_Phone.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Phone.Name = "LBL_Phone";
            this.LBL_Phone.Size = new System.Drawing.Size(127, 20);
            this.LBL_Phone.TabIndex = 18;
            this.LBL_Phone.Text = "Phone Number";
            // 
            // LBL_Address
            // 
            this.LBL_Address.AutoSize = true;
            this.LBL_Address.Location = new System.Drawing.Point(20, 228);
            this.LBL_Address.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Address.Name = "LBL_Address";
            this.LBL_Address.Size = new System.Drawing.Size(75, 20);
            this.LBL_Address.TabIndex = 17;
            this.LBL_Address.Text = "Address";
            // 
            // LBL_Email
            // 
            this.LBL_Email.AutoSize = true;
            this.LBL_Email.Location = new System.Drawing.Point(20, 188);
            this.LBL_Email.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Email.Name = "LBL_Email";
            this.LBL_Email.Size = new System.Drawing.Size(51, 20);
            this.LBL_Email.TabIndex = 16;
            this.LBL_Email.Text = "email";
            // 
            // LBL_FirstName
            // 
            this.LBL_FirstName.AutoSize = true;
            this.LBL_FirstName.Location = new System.Drawing.Point(20, 108);
            this.LBL_FirstName.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_FirstName.Name = "LBL_FirstName";
            this.LBL_FirstName.Size = new System.Drawing.Size(96, 20);
            this.LBL_FirstName.TabIndex = 15;
            this.LBL_FirstName.Text = "First Name";
            // 
            // LBL_Password
            // 
            this.LBL_Password.AutoSize = true;
            this.LBL_Password.Location = new System.Drawing.Point(20, 66);
            this.LBL_Password.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Password.Name = "LBL_Password";
            this.LBL_Password.Size = new System.Drawing.Size(86, 20);
            this.LBL_Password.TabIndex = 14;
            this.LBL_Password.Text = "Password";
            // 
            // LBL_Username
            // 
            this.LBL_Username.AutoSize = true;
            this.LBL_Username.Location = new System.Drawing.Point(13, 26);
            this.LBL_Username.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Username.Name = "LBL_Username";
            this.LBL_Username.Size = new System.Drawing.Size(91, 20);
            this.LBL_Username.TabIndex = 13;
            this.LBL_Username.Text = "Username";
            // 
            // TXT_LastName
            // 
            this.TXT_LastName.Location = new System.Drawing.Point(157, 143);
            this.TXT_LastName.Margin = new System.Windows.Forms.Padding(5);
            this.TXT_LastName.Name = "TXT_LastName";
            this.TXT_LastName.Size = new System.Drawing.Size(164, 26);
            this.TXT_LastName.TabIndex = 27;
            // 
            // LBL_LastName
            // 
            this.LBL_LastName.AutoSize = true;
            this.LBL_LastName.Location = new System.Drawing.Point(20, 148);
            this.LBL_LastName.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_LastName.Name = "LBL_LastName";
            this.LBL_LastName.Size = new System.Drawing.Size(95, 20);
            this.LBL_LastName.TabIndex = 26;
            this.LBL_LastName.Text = "Last Name";
            // 
            // LBL_Type
            // 
            this.LBL_Type.AutoSize = true;
            this.LBL_Type.Location = new System.Drawing.Point(18, 322);
            this.LBL_Type.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Type.Name = "LBL_Type";
            this.LBL_Type.Size = new System.Drawing.Size(118, 20);
            this.LBL_Type.TabIndex = 28;
            this.LBL_Type.Text = "Account Type";
            // 
            // CBX_AccountType
            // 
            this.CBX_AccountType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBX_AccountType.FormattingEnabled = true;
            this.CBX_AccountType.Items.AddRange(new object[] {
            "Customer",
            "Agency",
            "Staff",
            "Admin"});
            this.CBX_AccountType.Location = new System.Drawing.Point(157, 317);
            this.CBX_AccountType.Margin = new System.Windows.Forms.Padding(5);
            this.CBX_AccountType.Name = "CBX_AccountType";
            this.CBX_AccountType.Size = new System.Drawing.Size(164, 28);
            this.CBX_AccountType.TabIndex = 29;
            // 
            // CreateUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(908, 558);
            this.Controls.Add(this.CBX_AccountType);
            this.Controls.Add(this.LBL_Type);
            this.Controls.Add(this.TXT_LastName);
            this.Controls.Add(this.LBL_LastName);
            this.Controls.Add(this.TXT_UserName);
            this.Controls.Add(this.TXT_Password);
            this.Controls.Add(this.TXT_FirstName);
            this.Controls.Add(this.TXT_Email);
            this.Controls.Add(this.TXT_Address);
            this.Controls.Add(this.TXT_PhoneNumber);
            this.Controls.Add(this.CMD_Submit);
            this.Controls.Add(this.LBL_Phone);
            this.Controls.Add(this.LBL_Address);
            this.Controls.Add(this.LBL_Email);
            this.Controls.Add(this.LBL_FirstName);
            this.Controls.Add(this.LBL_Password);
            this.Controls.Add(this.LBL_Username);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "CreateUser";
            this.Text = "CreateUser";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateUser_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TXT_UserName;
        private System.Windows.Forms.TextBox TXT_Password;
        private System.Windows.Forms.TextBox TXT_FirstName;
        private System.Windows.Forms.TextBox TXT_Email;
        private System.Windows.Forms.TextBox TXT_Address;
        private System.Windows.Forms.TextBox TXT_PhoneNumber;
        private System.Windows.Forms.Button CMD_Submit;
        private System.Windows.Forms.Label LBL_Phone;
        private System.Windows.Forms.Label LBL_Address;
        private System.Windows.Forms.Label LBL_Email;
        private System.Windows.Forms.Label LBL_FirstName;
        private System.Windows.Forms.Label LBL_Password;
        private System.Windows.Forms.Label LBL_Username;
        private System.Windows.Forms.TextBox TXT_LastName;
        private System.Windows.Forms.Label LBL_LastName;
        private System.Windows.Forms.Label LBL_Type;
        private System.Windows.Forms.ComboBox CBX_AccountType;
    }
}