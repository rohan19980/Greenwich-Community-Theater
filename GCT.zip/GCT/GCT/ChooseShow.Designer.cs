﻿namespace GCT
{
    partial class ChooseShow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChooseShow));
            this.LBL_Production = new System.Windows.Forms.Label();
            this.LBL_Date = new System.Windows.Forms.Label();
            this.CBX_Productions = new System.Windows.Forms.ComboBox();
            this.CBX_Performance = new System.Windows.Forms.ComboBox();
            this.CMD_Select = new System.Windows.Forms.Button();
            this.CMD_CreateProduction = new System.Windows.Forms.Button();
            this.CMD_CreatePerformance = new System.Windows.Forms.Button();
            this.LLBL_Reviews = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.RTB_ProductionInfo = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // LBL_Production
            // 
            this.LBL_Production.AutoSize = true;
            this.LBL_Production.Location = new System.Drawing.Point(22, 88);
            this.LBL_Production.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Production.Name = "LBL_Production";
            this.LBL_Production.Size = new System.Drawing.Size(100, 20);
            this.LBL_Production.TabIndex = 0;
            this.LBL_Production.Text = "Production:";
            // 
            // LBL_Date
            // 
            this.LBL_Date.AutoSize = true;
            this.LBL_Date.Location = new System.Drawing.Point(48, 177);
            this.LBL_Date.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LBL_Date.Name = "LBL_Date";
            this.LBL_Date.Size = new System.Drawing.Size(53, 20);
            this.LBL_Date.TabIndex = 1;
            this.LBL_Date.Text = "Date:";
            // 
            // CBX_Productions
            // 
            this.CBX_Productions.FormattingEnabled = true;
            this.CBX_Productions.Location = new System.Drawing.Point(133, 83);
            this.CBX_Productions.Margin = new System.Windows.Forms.Padding(5);
            this.CBX_Productions.Name = "CBX_Productions";
            this.CBX_Productions.Size = new System.Drawing.Size(199, 28);
            this.CBX_Productions.TabIndex = 2;
            this.CBX_Productions.SelectedIndexChanged += new System.EventHandler(this.CBX_Productions_SelectedIndexChanged);
            // 
            // CBX_Performance
            // 
            this.CBX_Performance.FormattingEnabled = true;
            this.CBX_Performance.Location = new System.Drawing.Point(133, 173);
            this.CBX_Performance.Margin = new System.Windows.Forms.Padding(5);
            this.CBX_Performance.Name = "CBX_Performance";
            this.CBX_Performance.Size = new System.Drawing.Size(199, 28);
            this.CBX_Performance.TabIndex = 3;
            this.CBX_Performance.SelectedIndexChanged += new System.EventHandler(this.CBX_Performance_SelectedIndexChanged);
            // 
            // CMD_Select
            // 
            this.CMD_Select.Location = new System.Drawing.Point(167, 282);
            this.CMD_Select.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_Select.Name = "CMD_Select";
            this.CMD_Select.Size = new System.Drawing.Size(125, 35);
            this.CMD_Select.TabIndex = 4;
            this.CMD_Select.Text = "Select";
            this.CMD_Select.UseVisualStyleBackColor = true;
            this.CMD_Select.Click += new System.EventHandler(this.CMD_Select_Click);
            // 
            // CMD_CreateProduction
            // 
            this.CMD_CreateProduction.Location = new System.Drawing.Point(225, 121);
            this.CMD_CreateProduction.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_CreateProduction.Name = "CMD_CreateProduction";
            this.CMD_CreateProduction.Size = new System.Drawing.Size(107, 25);
            this.CMD_CreateProduction.TabIndex = 5;
            this.CMD_CreateProduction.Text = "Create";
            this.CMD_CreateProduction.UseVisualStyleBackColor = true;
            this.CMD_CreateProduction.Click += new System.EventHandler(this.CMD_CreateProduction_Click);
            // 
            // CMD_CreatePerformance
            // 
            this.CMD_CreatePerformance.Location = new System.Drawing.Point(225, 211);
            this.CMD_CreatePerformance.Margin = new System.Windows.Forms.Padding(5);
            this.CMD_CreatePerformance.Name = "CMD_CreatePerformance";
            this.CMD_CreatePerformance.Size = new System.Drawing.Size(107, 25);
            this.CMD_CreatePerformance.TabIndex = 6;
            this.CMD_CreatePerformance.Text = "Create";
            this.CMD_CreatePerformance.UseVisualStyleBackColor = true;
            this.CMD_CreatePerformance.Click += new System.EventHandler(this.CMD_CreatePerformance_Click);
            // 
            // LLBL_Reviews
            // 
            this.LLBL_Reviews.AutoSize = true;
            this.LLBL_Reviews.Location = new System.Drawing.Point(133, 126);
            this.LLBL_Reviews.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LLBL_Reviews.Name = "LLBL_Reviews";
            this.LLBL_Reviews.Size = new System.Drawing.Size(75, 20);
            this.LLBL_Reviews.TabIndex = 7;
            this.LLBL_Reviews.TabStop = true;
            this.LLBL_Reviews.Text = "Reviews";
            this.LLBL_Reviews.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LLBL_Reviews_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(161, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(436, 33);
            this.label1.TabIndex = 8;
            this.label1.Text = "Greenwich Community Theatre";
            // 
            // RTB_ProductionInfo
            // 
            this.RTB_ProductionInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RTB_ProductionInfo.Location = new System.Drawing.Point(359, 79);
            this.RTB_ProductionInfo.Name = "RTB_ProductionInfo";
            this.RTB_ProductionInfo.Size = new System.Drawing.Size(376, 157);
            this.RTB_ProductionInfo.TabIndex = 9;
            this.RTB_ProductionInfo.Text = "";
            // 
            // ChooseShow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(789, 452);
            this.Controls.Add(this.RTB_ProductionInfo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LLBL_Reviews);
            this.Controls.Add(this.CMD_CreatePerformance);
            this.Controls.Add(this.CMD_CreateProduction);
            this.Controls.Add(this.CMD_Select);
            this.Controls.Add(this.CBX_Performance);
            this.Controls.Add(this.CBX_Productions);
            this.Controls.Add(this.LBL_Date);
            this.Controls.Add(this.LBL_Production);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "ChooseShow";
            this.Text = "ChooseShow";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ChooseShow_FormClosing);
            this.Load += new System.EventHandler(this.ChooseShow_Load);
            this.VisibleChanged += new System.EventHandler(this.ChooseShow_VisibleChanged);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBL_Production;
        private System.Windows.Forms.Label LBL_Date;
        private System.Windows.Forms.ComboBox CBX_Productions;
        private System.Windows.Forms.ComboBox CBX_Performance;
        private System.Windows.Forms.Button CMD_Select;
        private System.Windows.Forms.Button CMD_CreateProduction;
        private System.Windows.Forms.Button CMD_CreatePerformance;
        private System.Windows.Forms.LinkLabel LLBL_Reviews;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox RTB_ProductionInfo;
    }
}

